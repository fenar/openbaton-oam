#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# powerdns spgw relation joined script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

#if [ -z "$spgw_dns_network_interface" ];then
#	echo "$SERVICE : spgw_dns_network_interface not defined, will use default : mgmt"
#	spgw_dns_network_interface="mgmt"
#fi

# Set the correct interface if we have changed the network name
#com=spgw_ip\=\$spgw_$spgw_dns_network_interface
#eval $com
#com=spgw_floating_ip\=\$spgw_$spgw_dns_network_interface\_floatingIp
#eval $com
#if [ ! $useFloatingIpsForEntries = "false" ]; then
#	if [ -z "$spgw_floating_ip" ]; then
#		echo "$SERVICE : there is no floatingIP for the $spgw_dns_network_interface network for mme ! Will fallback using the normal interface ip"
#		dns_ip=$spgw_ip
#	else
#		# Else we just overwrite the environment variable
#		dns_ip=$spgw_floating_ip
#	fi
#else
#	dns_ip=$spgw_ip
#fi


if [ -z "$spgw_mgmt" ] || [ -z "$spgw_net_a" ] || [ -z "$spgw_net_d" ];then
	echo "$SERVICE : spgw missing a network : mgmt=$spgw_mgmt , net_a=$spgw_net_a , net_d=$spgw_net_d"
	exit 1
fi

if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ];then
	check=$(cat $SCRIPTS_PATH/$RELATION_BUCKET | grep $spgw_mgmt | grep spgw_mgmt)
	if [ ! -z "$check" ];then
		echo "$SERVICE : We already got a relation to this spgw!"
		exit 0	
	fi
fi


# TODO :  WHAT ABOUT THE PRIORITY HERE?
# prio="10"
# Well, have a check if we already imported the basic epc template, this would mean that we already see an spgw scaling here!
if [ -f "$SCRIPTS_PATH/powerdns-imported-template" ];then
	echo "$SERVICE : powerdns has already imported the epc template, this means we currently build up a relation to a spgw which is scaled out"
	echo "$SERVICE : using template $SCRIPTS_PATH/$EPC_SPGW_TEMPLATE"
	echo "$SERVICE : will create $EPC_SPGW_EXTENDED_TEMPLATE"
	# accordingly check to remove a existing prefilled template
	if [ -f "$EPC_SPGW_EXTENDED_TEMPLATE" ];then
		rm $EPC_SPGW_EXTENDED_TEMPLATE
	fi
	# fill out the template
	if [ -f "$SCRIPTS_PATH/$EPC_SPGW_TEMPLATE" ];then
		# first entry
		cat $SCRIPTS_PATH/$EPC_SPGW_TEMPLATE | sed "s/VAR_REALM/$realm/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
		# and the rest
		#cat $EPC_SPGW_EXTENDED_TEMPLATE | sed "s/VAR_PRIO/$prio/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
		cat $EPC_SPGW_EXTENDED_TEMPLATE | sed "s/VAR_SPGW_NET_D/$spgw_net_d/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
	fi
	# Also save the new parameters into the relation bucket, so we may use them to restore a lost connection on scale in
	printf "$spgw_hostname\_spgw_mgmt=%s\n" \"$spgw_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
	printf "$spgw_hostname\_spgw_net_a=%s\n" \"$spgw_net_a\" >> $SCRIPTS_PATH/$RELATION_BUCKET
	printf "$spgw_hostname\_spgw_net_d=%s\n" \"$spgw_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET
fi


#if [ -z "$dns_ip" ];then
#	echo "$SERVICE : spgw has got no ip on $spgw_dns_network_interface !"
#	exit 1
#fi

#gmysql_api_key=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "api-key" | cut -d "=" -f 2) 
#curl -X PATCH --data "{\"rrsets\": [ {\"name\": \"spgw.$realm.\", \"type\": \"A\", \"ttl\": 86400, \"changetype\": \"REPLACE\", \"records\": [ {\"content\": \"$dns_ip\", \"disabled\": false } ] } ] }" -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones/$realm. >> $LOGFILE 2>&1

#printf "spgw_ip=%s\n" \"$dns_ip\" >> $SCRIPTS_PATH/$RELATION_BUCKET

if [ -z "$spgw_hostname" ];then
	echo "$SERVICE : Did not receive the hostname of the spgw, please check the relations"
	spgw_hostname="spgw"
fi

printf "$spgw_hostname\_spgw_mgmt=%s\n" \"$spgw_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "$spgw_hostname\_spgw_net_a=%s\n" \"$spgw_net_a\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "$spgw_hostname\_spgw_net_d=%s\n" \"$spgw_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET


# These values are always updated with the latest ones! Meaning we loose the values for an spgw we had a relation before..
if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*spgw_mgmt_ipv4=.*/spgw_mgmt_ipv4=\"$spgw_mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*spgw_net_a_ipv4=.*/spgw_net_a_ipv4=\"$spgw_net_a\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*spgw_net_d_ipv4=.*/spgw_net_d_ipv4=\"$spgw_net_d\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi
