#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# powerdns-admin installation script.
# Installs a web gui to allow easy control over
# powerdns itself.

export DEBIAN_FRONTEND=noninteractive

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

# Currently we have put together powerdns and powerdnsadmin and the related databases onto 1 vm.
# We may change this at a later phase.
pdns_host="127.0.0.1"
pdns_port="8081"
pdns_admin_db_host="127.0.0.1"

function prepare_config {
	cd $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME
	# Modify the bind address for powerdnsadmin
	###########################################################################################
	# This part will probably be interesting if you want to use multiple network interfaces
	# Check if we have the dns network interface name saved in the configuration parameters
	if [ -z "$dns_network_interface" ];then
		echo "$SERVICE : dns_network_interface not defined, will use default : mgmt"
		dns_network_interface="mgmt"
	fi
	# Set the correct interface
	com=pdns_ip\=\$$dns_network_interface
	eval $com
	# at this point we have our dns_ip ready to be used
	cat config.py | sed "s/^\.*BIND_ADDRESS.*/BIND_ADDRESS = '$pdns_ip' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	###########################################################################################
	# Check our local file for creating the mysql database for the username,password and database values
	###########################################################################################
	#gmysql_host=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "gmysql-host" | cut -d "=" -f 2)
	#gmysql_dbname=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "gmysql-dbname" | cut -d "=" -f 2)
	#gmysql_user=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "gmysql-user" | cut -d "=" -f 2)
	gmysql_password=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "gmysql-password" | cut -d "=" -f 2)
	gmysql_api_key=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "api-key" | cut -d "=" -f 2)   
	###########################################################################################
	# Modify the related information for powerdns-admin
	###########################################################################################
	#cat config.py | sed "s/^\.*SQLA_DB_HOST.*/SQLA_DB_HOST = '$gmysql_host' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	cat config.py | sed "s/^\.*PDNS_STATS_URL.*/PDNS_STATS_URL = 'http:\/\/$pdns_host:$pdns_port\/' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	cat config.py | sed "s/^\.*SQLA_DB_HOST.*/SQLA_DB_HOST = '$pdns_admin_db_host' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	#cat config.py | sed "s/^\.*SQLA_DB_USER.*/SQLA_DB_USER = '$gmysql_user' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	cat config.py | sed "s/^\.*SQLA_DB_PASSWORD.*/SQLA_DB_PASSWORD = '$gmysql_password' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	#cat config.py | sed "s/^\.*SQLA_DB_NAME.*/SQLA_DB_NAME = '$gmysql_dbname' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	cat config.py | sed "s/^\.*PDNS_API_KEY.*/PDNS_API_KEY = '$gmysql_api_key' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	cat config.py | sed "s/^\.*PDNS_VERSION.*/PDNS_VERSION = '$PDNS_API_VERSION' \n /" > $TMP_FILE && mv $TMP_FILE config.py
	###########################################################################################
	# Import the default database
	# $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/./create_db.py
	# Import our already existing database containing the openbaton user
	mysql -u root < $SCRIPTS_PATH/$TABLE_ADMIN_SKELETON
	# Comment all ldap lines in the config.py file since we dont use ldap yet for authentification
	sed -i '/LDAP/s/^/#/' $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/config.py
}

# Function to create us a pretty script to start the powerdnsadmin once we have rebooted the machine or killed the process
function powerdns_create_start_script {
	if [ -f "$POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/$POWERDNS_ADMIN_START_SCRIPT" ];then
		echo "$SERVICE : Found the start script for powerdnsadmin, will not create one"
	else
		echo "$SERVICE : Did not found start script for powerdnsadmin, will create the start script"
		cat >> $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/$POWERDNS_ADMIN_START_SCRIPT <<EOL
#!/bin/bash
check=\$(screen -ls | grep powerdns-admin)
if [ -z "\$check" ];then
	screen -dmS powerdns-admin
	screen -S powerdns-admin -p 0 -X stuff "cd $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME\$(printf \\\r)"
	screen -S powerdns-admin -p 0 -X stuff "source ./blackbox/bin/activate\$(printf \\\r)"
	screen -S powerdns-admin -p 0 -X stuff "./run.py\$(printf \\\r)"
else
	sec_check=\$(ps fax | grep python | grep PowerDNS-Admin )
	if [ -z "\$sec_check" ];then
		screen -S powerdns-admin -p 0 -X stuff "cd $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME\$(printf \\\r)"
		screen -S powerdns-admin -p 0 -X stuff "source ./blackbox/bin/activate\$(printf \\\r)"
		screen -S powerdns-admin -p 0 -X stuff "./run.py\$(printf \\\r)"
	fi
fi
EOL
	# Allow execution for the start script
	chmod +x $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/$POWERDNS_ADMIN_START_SCRIPT
	fi
}

function powerdns_admin_start {
	check=$(screen -ls | grep powerdns-admin)
	if [ -z "$check" ];then
		echo "$SERVICE : creating screen session for powerdns-admin"
		screen -dmS powerdns-admin
		screen -S powerdns-admin -p 0 -X stuff "bash$(printf \\r)"
		screen -S powerdns-admin -p 0 -X stuff "PATH=$(echo $PATH:/usr/local/bin)$(printf \\r)"
		screen -S powerdns-admin -p 0 -X stuff "cd $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME$(printf \\r)"
		echo "$SERVICE : Creating virtual environment"
		screen -S powerdns-admin -p 0 -X stuff "virtualenv blackbox$(printf \\r)"
		echo "$SERVICE : Joining virtual environment"
		screen -S powerdns-admin -p 0 -X stuff "source ./blackbox/bin/activate$(printf \\r)"
		if [ ! $downloadPackages = "false" ];then
			if [ ! -f "$SCRIPTS_PATH/powerdnsadmin-installed" ];then
				echo "$SERVICE : Will upgrade necessary pip packages to avoid crashing the install"
				pip install --upgrade $PIP_UPGRADE_PACKAGES >> $LOGFILE 2>&1
				echo "$SERVICE : Will install necessary pip packages for powerdns-admin"
				# pip install $PIP_PACKAGES >> $LOGFILE 2>&1
				screen -S powerdns-admin -p 0 -X stuff "pip install $PIP_PACKAGES >> $LOGFILE 2>&1$(printf \\r)"
				echo "$SERVICE : Installing requirements with pip"
				screen -S powerdns-admin -p 0 -X stuff "pip install -r requirements.txt >> $LOGFILE 2>&1$(printf \\r)"	
			fi	
		else
			echo "$SERVICE : Download packages was not set to true, assuming you have also installed all required pip packages and requirements"
			echo "$SERVICE : Updating the config for powerdnsadmin.."
			prepare_config
		fi
		screen -S powerdns-admin -p 0 -X stuff "./run.py$(printf \\r)"
	else
		echo "$SERVICE : powerdns-admin was already running, will NOT restart, check for active screen sessions"
	fi
}

# Take care not to run the script twice
if [ -f "$SCRIPTS_PATH/powerdnsadmin-installed" ];then
	echo "$SERVICE : powerdns-admin was installed already"
	# check if our service runs already, if not we can start it
	check=$(ps fax | grep python | grep PowerDNS-Admin )
	if [ -z "$check" ];then
		echo "There were no running PowerDNS-Admin processes, will start PowerDNS-Admin"
		powerdns_admin_start
	fi
	exit 0
fi

# Check if we have set the option to allow downloading packages
if [ ! $downloadPackages = "false" ];then
	echo "$SERVICE : Checking out the git repository and installing virtualenv"
	pip install virtualenv >> $LOGFILE 2>&1
	if [ -d "$POWERDNS_ADMIN_DIR" ];then
		echo "$SERVICE : Moving to powerdns-admin directory"
		cd $POWERDNS_ADMIN_DIR
	else
		echo "$SERVICE : Problem finding powerdns-admin directory!"
		exit 1
	fi
	git clone $POWERDNS_ADMIN_GIT_REPO >> $LOGFILE 2>&1
else
	echo "$SERVICE : Download packages was not set to true, assuming you have installed all necessary packages already"
fi

if [ -d "$POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME" ];then
	if [ -d "$POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/blackbox" ];then
		echo "$SERVICE : PowerDNS-Admin was already set up"
		if [ -z "$dns_network_interface" ];then
			echo "$SERVICE : dns_network_interface not defined, will use default : mgmt"
			dns_network_interface="mgmt"
		fi
		# Set the correct interface
		com=pdns_ip\=\$$dns_network_interface
		eval $com
		# at this point we have our dns_ip ready to be used
		cat $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/config.py | sed "s/^\.*BIND_ADDRESS.*/BIND_ADDRESS = '$pdns_ip' \n /" > $TMP_FILE && mv $TMP_FILE $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME/config.py
		powerdns_admin_start
	else
		cd $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME
		# Check if we find the config template
		if [ -f "config_template.py" ];then
			cp config_template.py config.py
		fi
		prepare_config
		# Start up
		powerdns_admin_start
		powerdns_create_start_script
		touch $SCRIPTS_PATH/powerdnsadmin-installed
	fi	
else
	echo "$SERVICE : Did not found the checked out git repository for powerdnsadmin in $POWERDNS_ADMIN_DIR/$POWERDNS_ADMIN_GIT_NAME"
	exit 1
fi

