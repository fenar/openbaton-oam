#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

expanded_template_name="template_extended.sql"

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

# Well in the meanwhile the spgw could have scaled... Thus we need to check for this and probably create the new entry for spgw!
# We will check for a extended template of the spgw kind.. That way it should work

echo "$SERVICE : want to use $EPC_SPGW_EXTENDED_TEMPLATE"
if [ -f "$EPC_SPGW_EXTENDED_TEMPLATE" ];then
	echo "$SERVICE : found extended template for additional spgw entry, this means we have scaled the spgw, importing the new entry"
	mysql -u root -f < $EPC_SPGW_EXTENDED_TEMPLATE 2>&1 >> $LOGFILE 2>&1
	exit 0
else
	echo "$SERVICE : There is no $EPC_SPGW_EXTENDED_TEMPLATE"
fi

# take care not to run the script twice
if [ -f "$SCRIPTS_PATH/powerdns-imported-template" ];then
	echo "$SERVICE : powerdns has already imported the epc template"
	exit 0
fi

touch $SCRIPTS_PATH/powerdns-imported-template

if [ -f "$OPENEPC_PATH/install/$EPC_EXPAND_TEMPLATE_SCRIPT" ];then
	$OPENEPC_PATH/install/./$EPC_EXPAND_TEMPLATE_SCRIPT $SCRIPTS_PATH/$EPC_POWERDNS_TEMPLATE $SCRIPTS_PATH/$expanded_template_name
	if [ -f "$SCRIPTS_PATH/$expanded_template_name" ];then
		mysql -u root -f < $SCRIPTS_PATH/$expanded_template_name 2>&1 >> $LOGFILE 2>&1
	fi
fi

echo "nameserver 127.0.0.1" >> /etc/resolvconf/resolv.conf.d/head
echo "domain $realm" >> /etc/resolvconf/resolv.conf.d/head
#echo "search $realm" >> /etc/resolvconf/resolv.conf.d/head

resolvconf -u 2>&1 >> $LOGFILE
