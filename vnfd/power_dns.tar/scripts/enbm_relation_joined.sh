#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# powerdns enbm relation joined script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

#if [ -z "$enbm_dns_network_interface" ];then
#	echo "$SERVICE : enbm_dns_network_interface not defined, will use default : mgmt"
#	enbm_dns_network_interface="mgmt"
#fi

# Set the correct interface if we have changed the network name
#com=enbm_ip\=\$enbm_$enbm_dns_network_interface
#eval $com
#com=enbm_floating_ip\=\$enbm_$enbm_dns_network_interface\_floatingIp
#eval $com
#if [ ! $useFloatingIpsForEntries = "false" ]; then
#	if [ -z "$enbm_floating_ip" ]; then
#		echo "$SERVICE : there is no floatingIP for the $enbm_dns_network_interface network for mme ! Will fallback using the #normal interface ip"
#		dns_ip=$enbm_ip
#	else
#		# Else we just overwrite the environment variable
#		dns_ip=$enbm_floating_ip
#	fi
#else
#	dns_ip=$enbm_ip
#fi

if [ -z "$enbm_mgmt" ] || [ -z "$enbm_net_c" ] || [ -z "$enbm_net_d" ];then
	echo "$SERVICE : Enodeb missing a network : mgmt=$enbm_mgmt , net_c=$enbm_net_c , net_d=$enbm_net_d"
	exit 1
fi

if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ];then
	check=$(cat $SCRIPTS_PATH/$RELATION_BUCKET | grep $enbm_mgmt | grep enbm_mgmt)
	if [ ! -z "$check" ];then
		echo "$SERVICE : We already got a relation to this enbm!"
		exit 0	
	fi
fi


#if [ -z "$dns_ip" ];then
#	echo "$SERVICE : enbm has got no ip on $enbm_dns_network_interface !"
#	exit 1
#fi

#gmysql_api_key=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "api-key" | cut -d "=" -f 2) 
#curl -X PATCH --data "{\"rrsets\": [ {\"name\": \"enodeb.$realm.\", \"type\": \"A\", \"ttl\": 86400, \"changetype\": \"REPLACE\", \"records\": [ {\"content\": \"$dns_ip\", \"disabled\": false } ] } ] }" -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones/$realm. >> $LOGFILE 2>&1

#printf "enbm_ip=%s\n" \"$dns_ip\" >> $SCRIPTS_PATH/$RELATION_BUCKET

printf "enbm_mgmt=%s\n" \"$enbm_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "enbm_net_c=%s\n" \"$enbm_net_c\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "enbm_net_d=%s\n" \"$enbm_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET

if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*enodeb_mgmt_ipv4=.*/enodeb_mgmt_ipv4=\"$enbm_mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*enodeb_net_c_ipv4=.*/enodeb_net_c_ipv4=\"$enbm_net_c\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*enodeb_net_d_ipv4=.*/enodeb_net_d_ipv4=\"$enbm_net_d\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi
