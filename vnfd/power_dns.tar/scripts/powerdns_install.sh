#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# powerdns installation script.


function create_domain {
	# This part will probably be interesting if you want to use multiple network interfaces
	# Check if we have the dns network interface name saved in the configuration parameters
	if [ -z "$dns_network_interface" ];then
		echo "$SERVICE : dns_network_interface not defined, will use default : mgmt"
		dns_network_interface="mgmt"
	fi
	# Set the correct interface if we have changed the network name..
	com=pdns_ip\=\$$dns_network_interface
	eval $com
	com=pdns_floating_ip\=\$$dns_network_interface\_floatingIp
	eval $com
	if [ ! $useFloatingIpsForEntries = "false" ]; then
		if [ -z "$pdns_floating_ip" ]; then
			echo "$SERVICE : there is no floatingIP for the $dns_network_interface network for powerdns ! Will fallback using the normal interface ip"
			dns_ip=$pdns_ip
		else
			# Else we just overwrite the environment variable
			dns_ip=$pdns_floating_ip
		fi
	else
		dns_ip=$pdns_ip
	fi
	visisted=$(echo $realm | sed "s/mnc[0-9][0-9][0-9]/mnc002/")

	#echo "$SERVICE : Creating initial entries"
	#gmysql_api_key=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "api-key" | cut -d "=" -f 2) 
	#curl -X POST --data "{\"name\":\"$realm.\", \"kind\": \"Native\", \"masters\": [], \"nameservers\": [\"ns.$realm.\"]}" -v -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones >> $LOGFILE 2>&1
	#sleep 2s
	#curl -X PATCH --data "{\"rrsets\": [ {\"name\": \"ns.$realm.\", \"type\": \"A\", \"ttl\": 86400, \"changetype\": \"REPLACE\", \"records\": [ {\"content\": \"$dns_ip\", \"disabled\": false } ] } ] }" -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones/$realm. >> $LOGFILE 2>&1
	#sleep 2s
	#curl -X PATCH --data "{\"rrsets\": [ {\"name\": \"dns.$realm.\", \"type\": \"A\", \"ttl\": 86400, \"changetype\": \"REPLACE\", \"records\": [ {\"content\": \"$dns_ip\", \"disabled\": false } ] } ] }" -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones/$realm. >> $LOGFILE 2>&1
	#sleep 2s
	#curl -X PATCH --data "{\"rrsets\": [ {\"name\": \"gw.$realm.\", \"type\": \"A\", \"ttl\": 86400, \"changetype\": \"REPLACE\", \"records\": [ {\"content\": \"192.168.3.1\", \"disabled\": false } ] } ] }" -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones/$realm. >> $LOGFILE 2>&1
	#sleep 2s
	#curl -X POST --data "{\"name\":\"$visited.\", \"kind\": \"Native\", \"masters\": [], \"nameservers\": [\"ns.$visited.\"]}" -v -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones >> $LOGFILE 2>&1

}

# Necessary so will not be prompted to enter a password for the mysql-root user
export DEBIAN_FRONTEND=noninteractive

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

# take care not to run the script twice
if [ -f "$SCRIPTS_PATH/powerdns-installed" ];then
	echo "$SERVICE : powerdns was installed already"
	# check if our service runs already, if not we can start it
	check=$(ps fax | grep pdns_server)
	if [ -z "$check" ];then
		service pdns start
		sleep 4s
		create_domain
	fi
	exit 0
fi
touch $SCRIPTS_PATH/powerdns-installed

echo "$SERVICE : Installing packages"
# Install packages and redirect stderr to our logfile

# Check if we have set the option to allow downloading packages
if [ ! $downloadPackages = "false" ];then
	echo "$SERVICE : Will install : $INSTALL_PACKAGES"
	apt-get update >> $LOGFILE 2>&1 && echo "$SERVICE : Finished update now installing packages" && apt-get install -y -q $INSTALL_PACKAGES >> $LOGFILE 2>&1
	echo "$SERVICE : Finished installing packages"
fi

# Allow connections to the database from the outside
cat $MYSQL_CONF | sed "s/^\.*bind-address.*/bind-address = 0.0.0.0 \n /" > $TMP_FILE && mv $TMP_FILE $MYSQL_CONF
#service mysql restart


# Now install powerdns ... Since in the official repos there is only 3.3 we need to work on the
# bleeding edge versions ...
if [ ! $downloadPackages = "false" ];then
	echo "Package: pdns-*"  >> $PDNS_APT_PREF_FILE
	echo "Pin: origin repo.powerdns.com"  >> $PDNS_APT_PREF_FILE
	echo "Pin-Priority: 600"  >> $PDNS_APT_PREF_FILE

	version=$(lsb_release -a | grep Description | cut -d ":" -f 2)
	echo "$SERVICE : Operating system : $version"
	# Lets check it with wildcards
	if [[ $version == *"14.04"* ]];then
		if [ ! -f "$PDNS_APT_FILE" ];then
			echo $PDNS_TRUSTY_REPO >> $PDNS_APT_FILE
			curl $PDNS_TRUSTY_KEY | apt-key add - && apt-get update >> $LOGFILE 2>&1 && apt-get install pdns-server -y -q >> $LOGFILE 2>&1
		fi
	elif [[ $version == *"16.04"* ]];then
		if [ ! -f "$PDNS_APT_FILE" ];then
			echo $PDNS_XENIAL_REPO >> $PDNS_APT_FILE
			curl $PDNS_XENIAL_KEY | apt-key add - && apt-get update >> $LOGFILE 2>&1 && apt-get install pdns-server -y -q >> $LOGFILE 2>&1
		fi
	else
		echo "$SERVICE : Not supporting the OS : $version , currently only 14.04 and 16.04 are supported..."
		exit 1
	fi


fi

# Next step is now to import the default table structure
if [ -f "$SCRIPTS_PATH/$TABLE_SKELETON" ];then
	echo "$SERVICE : Found mysql table skeleton, will import it"
	mysql -u root < $SCRIPTS_PATH/$TABLE_SKELETON
fi

# Clear up the default config files, check if dir exists and its empty
if [ -d "$POWERDNS_DIR" ];then
	echo "$SERVICE : Found powerdns config directory... Cleaning up"
	[ "$(ls -A $POWERDNS_DIR)" ] && rm $POWERDNS_DIR/* || echo "$SERVICE : directory was cleaned up already"
 	#find $POWERDNS_DIR -type d -empty -exec echo "directory is empty" \;
fi

# Copy our sample config file into the powerdns config directory
if [ -f "$SCRIPTS_PATH/$POWERDNS_CONF" ];then
	echo "$SERVICE : Copying powerdns config files"
	cp $SCRIPTS_PATH/$POWERDNS_CONF $POWERDNS_DIR
fi

# Restart pdns to force reloading the config file, this will be done anyway when we install the mysql-backend!
if [ ! $downloadPackages = "false" ];then
	sudo apt-get install -y -q $INSTALL_BACKEND_PACKAGES >> $LOGFILE 2>&1
else
	service pdns restart
fi

# Check if pdns is up and running, if the variable pdns_status is not empty , pdns is not running
pdns_status=$(service pdns status | grep not)
if [ ! -z "$pdns_status" ];then
	echo "$SERVICE : powerdns did not restart properly!"
	exit 1
fi

# Be sure pdns is ready to answer, so this script will not fail due to this issue..
sleep 4s

# Now also check if we can reach our local power-dns, same as before, if the variables is not empty, we have a problem
pdns_status=$(dig @localhost | grep "timed out")
if [ ! -z "$pdns_status" ];then
	echo "$SERVICE : dig@localhost failed! Connection time out!"
	exit 1
fi

create_domain

if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*dns_mgmt_ipv4=.*/dns_mgmt_ipv4=\"$mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*dns_net_a_ipv4=.*/dns_net_a_ipv4=\"$net_a\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi
