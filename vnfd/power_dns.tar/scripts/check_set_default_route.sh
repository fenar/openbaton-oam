#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# Script to check for floating Ips on the network interfaces,
# so the default route is in the end set via the dns_network_interface
# if we got a floating-ip there, else keep the route via the other network..


function set_default_route_to_interface {
	if [ -z "$1" ];then
		echo "$SERVICE : not changing the route, missing parameter"
	else
		sleep 8s
		new_ip=$(ip route | grep mgmt | grep scope | cut -d " " -f 1 | cut -d "." -f 1-3)
		ip route replace default via $new_ip.1 dev $1
	fi
}


export DEBIAN_FRONTEND=noninteractive

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

old_default_route=$(ip route | grep default)
old_default_r_intf=$(echo $old_default_route | awk '{print $5}')
echo "$SERVICE : Old default route is $old_default_route , interface is $old_default_r_intf"

# Now check if we have a floating IP on that network..
# We can only do this since we already renamed the network interfaces

com=network_check\=\$$mgmt_network_interface\_floatingIp
eval $com

com=network2_check\=\$$net_a_network_interface\_floatingIp
eval $com

# Check on which interface dns is working
if [ "$dns_network_interface" == "$mgmt_network_interface" ];then
	# now check for existing floating Ip on that network
	if [ -z "$network_check" ];then
		# well, in this case there is no floating Ip for the mgmt network defined
		# so check for the default route
		if [ "$old_default_r_intf" == "$mgmt_network_interface" ];then
			# here we have a problem! we need to change the default route to the net_a network!
			echo "$SERVICE : dns_interface set to $mgmt_network_interface, default route currently on $mgmt_network_interface, but no floating ip on $mgmt_network_interface!"
			( set_default_route_to_interface $net_a_network_interface &)
		else
			# well, here we dont care anymore and just assume the other network already has a flaoting Ip
			echo "$SERVICE : dns_interface set to $mgmt_network_interface, default route currently not on $mgmt_network_interface, we keep everything as it is since we do not have a floating ip on $mgmt_network_interface"
		fi 
	else
		# good, we have the dns_interface set to mgmt and we got a floating IP on mgmt
		# all to check if we have set the default route already over this network
		if [ "$old_default_r_intf" == "$mgmt_network_interface" ];then
			# All good in this case, everything is the way we want it
			echo "$SERVICE : dns_interface , default route going over $mgmt_network_interface where we have a floating Ip, will not touch the routes"
		else
			# Well we can change the default route to the dns_network_interface since everything runs over there
			echo "$SERVICE : changing default route to $mgmt_network_interface since dns_network_interface is defined to this network and we got a floating ip ready"
			( set_default_route_to_interface $mgmt_network_interface &)
		fi
	fi

elif [ "$dns_network_interface" == "$net_a_network_interface" ];then
	# now check for existing floating Ip on that network
	if [ -z "$network2_check" ];then
		# well, in this case there is no floating Ip for the net_a network defined
		# so check for the default route
		if [ "$old_default_r_intf" == "$net_a_network_interface" ];then
			# here we have a problem! we need to change the default route to the mgmt network!
			echo "$SERVICE : dns_interface set to $net_a_network_interface, default route currently on $net_a_network_interface, but no floating ip on $net_a_network_interface!"
			( set_default_route_to_interface $mgmt_network_interface &)
		else
			# well, here we dont care anymore and just assume the other network already has a flaoting Ip
			echo "$SERVICE : dns_interface set to $net_a_network_interface, default route currently not on $net_a_network_interface, we keep everything as it is since we do not have a floating ip on $net_a_network_interface"
		fi 
	else
		# good, we have the dns_interface set to net_a and we got a floating IP on net_a
		# all to check if we have set the default route already over this network
		if [ "$old_default_r_intf" == "$net_a_network_interface" ];then
			# All good in this case, everything is the way we want it
			echo "$SERVICE : dns_interface , default route going over $net_a_network_interface where we have a floating Ip, will not touch the routes"
		else
			# Well we can change the default route to the dns_network_interface since everything runs over there
			echo "$SERVICE : changing default route to $net_a_network_interface since dns_network_interface is defined to this network and we got a floating ip ready"
			( set_default_route_to_interface $net_a_network_interface &)
		fi
	fi
else
	echo "$SERVICE : dns_network_interface is set to a non existing network, will not touch any routes on the machine"
fi

