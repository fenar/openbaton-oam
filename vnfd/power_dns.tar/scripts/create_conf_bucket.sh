#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# Script to throw all our configuration parameters + default options into
# Eases our lifes trying to debug when being directly in the vm

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi 

printf "source %s\n" \"$SCRIPTS_PATH/default_options\" >> $SCRIPTS_PATH/$CONF_BUCKET
printf "mgmt_network_interface=%s\n" \"$mgmt_network_interface\" >> $SCRIPTS_PATH/$CONF_BUCKET
printf "net_d_network_interface=%s\n" \"$net_d_network_interface\" >> $SCRIPTS_PATH/$CONF_BUCKET
printf "dns_network_interface=%s\n" \"$dns_network_interface\" >> $SCRIPTS_PATH/$CONF_BUCKET
printf "realm=%s\n" \"$realm\" >> $SCRIPTS_PATH/$CONF_BUCKET
printf "useFloatingIpsForEntries=%s\n" \"$useFloatingIpsForEntries\" >> $SCRIPTS_PATH/$CONF_BUCKET
printf "downloadPackages=%s\n" \"$downloadPackages\" >> $SCRIPTS_PATH/$CONF_BUCKET
