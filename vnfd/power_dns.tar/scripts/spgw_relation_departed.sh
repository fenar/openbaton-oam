#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# powerdns spgw relation departed script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi


# Well we need to check if we remove the current spgw which is defined in the powerdns

curr_ip=$(getent hosts net-d.spgw.node | awk '{ print $1 }')

# Delete all relating entries to this hostname!
sed -i "/$removing_hostname/d" $SCRIPTS_PATH/$RELATION_BUCKET

echo "$SERVICE : checking : $curr_ip against : $removing_net_d"
if [ "$curr_ip" == "$removing_net_d" ];then
	echo "$SERVICE : scale_in is deleting the current entry, need to restore from a spgw before!"
	# Switch back to an old spgw which was replaced by the one we will delete now
	replace_ip=$(cat $SCRIPTS_PATH/$RELATION_BUCKET | grep spgw | grep $net_d_network_interface | head -n 1 | cut -d '"' -f 2)
	echo "$SERVICE : using template $SCRIPTS_PATH/$EPC_SPGW_TEMPLATE"
	echo "$SERVICE : will create $EPC_SPGW_EXTENDED_TEMPLATE"
	# accordingly check to remove a existing prefilled template
	if [ -f "$EPC_SPGW_EXTENDED_TEMPLATE" ];then
		rm $EPC_SPGW_EXTENDED_TEMPLATE
	fi
	# fill out the template
	if [ -f "$SCRIPTS_PATH/$EPC_SPGW_TEMPLATE" ];then
		# first entry
		cat $SCRIPTS_PATH/$EPC_SPGW_TEMPLATE | sed "s/VAR_REALM/$realm/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
		cat $EPC_SPGW_EXTENDED_TEMPLATE | sed "s/VAR_SPGW_NET_D/$replace_ip/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
	fi
	# And import the modified template to update the dns entry
	mysql -u root -f < $EPC_SPGW_EXTENDED_TEMPLATE 2>&1 >> $LOGFILE 2>&1
else
	echo "$SERVICE : scale_in is not deleting the current entry, nothing to do"
fi

