#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# powerdns mme relation joined script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

#if [ -z "$mme_dns_network_interface" ];then
#	echo "$SERVICE : mme_dns_network_interface not defined, will use default : mgmt"
#	mme_dns_network_interface="mgmt"
#fi

# Set the correct interface if we have changed the network name
#com=mme_ip\=\$mme_$mme_dns_network_interface
#eval $com
#com=mme_floating_ip\=\$mme_$mme_dns_network_interface\_floatingIp
#eval $com

#if [ ! $useFloatingIpsForEntries = "false" ]; then
#	if [ -z "$mme_floating_ip" ]; then
#		echo "$SERVICE : there is no floatingIP for the $mme_dns_network_interface network for mme ! Will fallback using the normal interface ip"
#		dns_ip=$mme_ip
#	else
#		# Else we just overwrite the environment variable
#		dns_ip=$mme_floating_ip
#	fi
#else
#	dns_ip=$mme_ip
#fi

if [ -z "$mme_mgmt" ] || [ -z "$mme_net_d" ];then
	echo "$SERVICE : mme missing a network : mgmt=$enbm_mgmt, net_d=$enbm_net_d"
	exit 1
fi

if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ];then
	check=$(cat $SCRIPTS_PATH/$RELATION_BUCKET | grep $mme_mgmt | grep mme_mgmt)
	if [ ! -z "$check" ];then
		echo "$SERVICE : We already got a relation to this mme!"
		exit 0	
	fi
fi


#if [ -z "$dns_ip" ];then
#	echo "$SERVICE : mme has got no ip on $mme_dns_network_interface !"
#	exit 1
#fi

#gmysql_api_key=$(cat $POWERDNS_DIR/$POWERDNS_CONF | grep "api-key" | cut -d "=" -f 2) 
#curl -X PATCH --data "{\"rrsets\": [ {\"name\": \"mme.$realm.\", \"type\": \"A\", \"ttl\": 86400, \"changetype\": \"REPLACE\", \"records\": [ {\"content\": \"$dns_ip\", \"disabled\": false } ] } ] }" -H "X-API-Key: $gmysql_api_key" http://127.0.0.1:8081/api/v1/servers/localhost/zones/$realm. >> $LOGFILE 2>&1


#printf "mme_ip=%s\n" \"$dns_ip\" >> $SCRIPTS_PATH/$RELATION_BUCKET

printf "mme_mgmt=%s\n" \"$mme_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_net_d=%s\n" \"$mme_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET

if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*mme_mgmt_ipv4=.*/mme_mgmt_ipv4=\"$mme_mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*mme_net_d_ipv4=.*/mme_net_d_ipv4=\"$mme_net_d\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP

fi
