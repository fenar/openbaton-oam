#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# mme hss relation joined script
# Get the ips from mgmt and save them for later usage.
# Probably optionally in the case of the deployment since we may use the dns hostnames

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

if [ -z "$hss_mgmt_network_interface" ];then
	echo "$SERVICE : hss_mgmt_network_interface not defined, will use default : mgmt"
	hss_mgmt_network_interface="mgmt"
fi

# Set the correct interface if we have changed the network names
com=hss_ip_mgmt\=\$hss_$hss_mgmt_network_interface
eval $com
com=hss_floating_ip_mgmt\=\$hss_$hss_mgmt_network_interface\_floatingIp
eval $com

if [ -z "$hss_ip_mgmt" ];then
	echo "$SERVICE : hss has not ip on network $hss_mgmt_network_interface !"
	exit 1
fi

#################################################################################################
# If we would need additional informations we should try to get all values from the powerdns	#
# in the START_LIFECYCLE and not substitute them in the relation scripts			#
#################################################################################################
if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*hss_mgmt_ipv4=.*/hss_mgmt_ipv4=\"$hss_ip_mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi


# Save all IPs, the ones we get from openbaton + the ones we calculated,
# so we may afterwards check if the networks have been renamed
printf "hss_mgmt=%s\n" \"$hss_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "hss_ip_mgmt=%s\n" \"$hss_ip_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "hss_mgmt_floatingIp=%s\n" \"$hss_mgmt_floatingIp\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "hss_floating_ip_mgmt=%s\n" \"$hss_floating_ip_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET

