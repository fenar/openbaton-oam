#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# mme install script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ];then
	source $SCRIPTS_PATH/$RELATION_BUCKET
fi

if [ -z "$mgmt_network_interface" ];then
	echo "$SERVICE : mgmt_network_interface not defined, will use default : mgmt"
	mgmt_network_interface="mgmt"
fi
if [ -z "$net_d_network_interface" ];then
	echo "$SERVICE : net_d_network_interface not defined, will use default : net_d"
	net_d_network_interface="net_d"
fi

# Set the correct interface if we have changed the network name..
# We override the default values here
com=mgmt\=\$$mgmt_network_interface
echo "$SERVICE : mgmt ip before check : $mgmt on $mgmt_network_interface"
eval $com
echo "$SERVICE : mgmt ip after check : $mgmt on $mgmt_network_interface"
echo "$SERVICE : mgmt_floatingIp before check : $mgmt_floatingIp on $mgmt_network_interface"
com=mgmt_floatingIp\=\$$mgmt_network_interface\_floatingIp
eval $com
echo "$SERVICE : mgmt_floatingIp after check : $mgmt_floatingIp on $mgmt_network_interface"
echo "$SERVICE : net_d ip before check : $net_d on $net_d_network_interface"
com=net_d\=\$$net_d_network_interface
eval $com
echo "$SERVICE : net_d ip before after : $net_d on $net_d_network_interface"
echo "$SERVICE : net_d_floatingIp before check : $net_d_floatingIp on $net_d_network_interface"
com=net_d_floatingIp\=\$$net_d_network_interface\_floatingIp
eval $com
echo "$SERVICE : net_d_floatingIp after check : $net_d_floatingIp on $net_d_network_interface"


# Now also find out the ipv6 related values for our networks

#ipv6_mgmt_complete=$(ifconfig $mgmt_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#ipv6_mgmt_ip=$(echo $ipv6_mgmt_complete | cut -d "/" -f 1)

#while [ -z "$ipv6_net_d_complete" ]
#do
#	echo "$SERVICE : Checking for net_d ipv6 address"
#	ipv6_net_d_complete=$(ifconfig $net_d_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#	if [ -z "$ipv6_net_d_complete" ];then
#		# If the Global scope is not available, use the link scope
#		ipv6_net_d_complete=$(ifconfig $net_d_network_interface | grep "inet6 addr" | grep "Link" | awk '{print $3}')
#	fi
#	sleep 8s
#done

#ipv6_net_d_ip=$(echo $ipv6_net_d_complete | cut -d "/" -f 1)
#ipv6_net_d_prefix=$(echo $ipv6_net_d_complete | cut -d "/" -f 2)

# Substitute the related values in the data_topology_vars.sh file ( for mme )
if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*mme_mgmt_ipv4=.*/mme_mgmt_ipv4=\"$mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*mme_net_d_ipv4=.*/mme_net_d_ipv4=\"$net_d\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*mme_net_d_ipv6=.*/mme_net_d_ipv6=\"$ipv6_net_d_ip\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*mme_net_d_prefixv6.*/mme_net_d_prefixv6=\"\$mme_net_d_ipv6\/$ipv6_net_d_prefix\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi


# Do not forget to update the userparameter file!
#cat $SCRIPTS_PATH/$USER_PARAM | sed "s/\VAR_MME_MGMT/$mgmt/g" > $TMP_FILE && mv $TMP_FILE $SCRIPTS_PATH/$USER_PARAM


# And if there is the zabbix agent available, also put our userparameter file into the zabbix-agent dir
if [ -f "/etc/zabbix/zabbix_agentd.conf" ];then
	echo "UnsafeUserParameters=1" >> /etc/zabbix/zabbix_agentd.conf
	if [ -d "/etc/zabbix/zabbix_agentd.conf.d" ];then
		cat /etc/zabbix/zabbix_agentd.conf.d/$USER_PARAM | sed "s/\VAR_MME_MGMT/$mgmt/g" > $TMP_FILE && mv $TMP_FILE /etc/zabbix/zabbix_agentd.conf.d/$USER_PARAM
		#cp $SCRIPTS_PATH/$USER_PARAM /etc/zabbix/zabbix_agentd.conf.d/
	fi

fi

# do not forget to reload the changes into the zabbix-agent

service zabbix-agent restart 2>&1



