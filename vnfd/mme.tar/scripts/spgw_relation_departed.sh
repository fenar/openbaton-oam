#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# mme spgw relation departed script


############# 		 ############# 	
############# Workaround ############# 
#############		 ############# 
if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
fi
#############		############# 
#############		############# 


# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

switch_num_file="$SCRIPTS_PATH/swich_num"


if [ -z "$removing_net_d" ];then
	echo "$SERVICE : spgw missing net_d address!"
	exit 1
fi

echo "$SERVICE : checking for $removing_net_d in $SCRIPTS_PATH/$RELATION_BUCKET"
check=$(cat $SCRIPTS_PATH/$RELATION_BUCKET | grep $removing_net_d )
if [ -z "$check" ];then
	echo "$SERVICE :  We already deleted the relation to this spgw!"
	exit 0
fi

# Well all we do with this script is to count the number of currently existing spgws,
# it goes hand in hand with the spgw_relation_joined script.

# The number we will manage here is used for deciding when to scale the spgw.
# We devide the number of users by the number of spgws.

if [ ! -f "$switch_num_file" ];then
	echo "$SERVICE : There was no spgw connected yet!"
else
	sn=$(cat $switch_num_file )
	sn=$(echo "$sn -1" | bc)
	echo $sn > $switch_num_file
	echo "$SERVICE : spgw scaled in ! We now have $sn spgws"
fi


# in the very end also save the spgw which was connecting by its net_d address

if [ -z "$removing_hostname" ];then
	echo "$SERVICE : Did not receive the hostname of the spgw, please check the relations"
	removing_hostname="spgw"
fi

echo "$SERVICE : Deleting entry $removing_hostname from $SCRIPTS_PATH/$RELATION_BUCKET"
sed -i "/$removing_hostname/d" $SCRIPTS_PATH/$RELATION_BUCKET





