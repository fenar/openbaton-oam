#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# mme spgw relation joined script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

switch_num_file="$SCRIPTS_PATH/swich_num"

# Well all we do with this script is to count the number of currently existing spgws,
# it goes hand in hand with the spgw_relation_departed script.

# The number we will manage here is used for deciding when to scale the spgw.
# We devide the number of users by the number of spgws.

if [ -z "$spgw_net_d" ];then
	echo "$SERVICE : spgw missing net_d address!"
	exit 1
fi

check=$(cat $SCRIPTS_PATH/$RELATION_BUCKET | grep $spgw_net_d )
if [ ! -z "$check" ];then
	echo "$SERVICE :  We already have a relation to this spgw!"
	exit 0
fi

if [ ! -f "$switch_num_file" ];then
	echo "$SERVICE : We have the first spgw connecting!"
	echo "1" > $switch_num_file
else
	sn=$(cat $switch_num_file )
	sn=$(echo $sn +1 | bc)
	echo $sn > $switch_num_file
	echo "$SERVICE : spgw scaled out! We now have $sn spgws"
fi


# in the very end also save the spgw which was connecting by its net_d address

if [ -z "$spgw_hostname" ];then
	echo "$SERVICE : Did not receive the hostname of the spgw, please check the relations"
	spgw_hostname="spgw"
fi

printf "$spgw_hostname=%s\n" \"$spgw_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET



