#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# hss install script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ];then
	source $SCRIPTS_PATH/$RELATION_BUCKET
fi

if [ -z "$mgmt_network_interface" ];then
	echo "$SERVICE : mgmt_network_interface not defined, will use default : mgmt"
	mgmt_network_interface="mgmt"
fi
#if [ -z "$net_a_network_interface" ];then
#	echo "$SERVICE : net_a_network_interface not defined, will use default : net_a"
#	net_a_network_interface="net_a"
#fi

# Set the correct interface if we have changed the network name..
# We override the default values here
com=mgmt\=\$$mgmt_network_interface
echo "$SERVICE : mgmt ip before check : $mgmt on $mgmt_network_interface"
eval $com
echo "$SERVICE : mgmt ip after check : $mgmt on $mgmt_network_interface"
echo "$SERVICE : mgmt_floatingIp before check : $mgmt_floatingIp on $mgmt_network_interface"
com=mgmt_floatingIp\=\$$mgmt_network_interface\_floatingIp
eval $com
echo "$SERVICE : mgmt_floatingIp after check : $mgmt_floatingIp on $mgmt_network_interface"
#echo "$SERVICE : net_a ip before check : $net_a on $net_a_network_interface"
#com=net_a\=\$$net_a_network_interface
#eval $com
#echo "$SERVICE : net_a ip before after : $net_a on $net_a_network_interface"
#echo "$SERVICE : net_a_floatingIp before check : $net_a_floatingIp on $net_a_network_interface"
#com=net_a_floatingIp\=\$$net_a_network_interface\_floatingIp
#eval $com
#echo "$SERVICE : net_a_floatingIp after check : $net_a_floatingIp on $net_a_network_interface"


# Now also find out the ipv6 related values for our networks

#ipv6_mgmt_complete=$(ifconfig $mgmt_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#ipv6_mgmt_ip=$(echo $ipv6_mgmt_complete | cut -d "/" -f 1)
#ipv6_net_a_complete=$(ifconfig $net_a_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#if [ -z "$ipv6_net_a_complete" ];then
#	# If the Global scope is not available, use the link scope
#	ipv6_net_a_complete=$(ifconfig $net_a_network_interface | grep "inet6 addr" | grep "Link" | awk '{print $3}')
#fi
#ipv6_net_a_ip=$(echo $ipv6_net_a_complete | cut -d "/" -f 1)

# Substitute the related values in the data_topology_vars.sh file ( for hss )

if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*hss_mgmt_ipv4=.*/hss_mgmt_ipv4=\"$mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*hss_net_a_ipv4=.*/hss_net_a_ipv4=\"$net_a\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*hss_net_a_ipv6=.*/hss_net_a_ipv6=\"$ipv6_net_a_ip\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*hss_net_a_prefixv6.*/hss_net_a_prefixv6=\"$ipv6_net_a_complete\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi
