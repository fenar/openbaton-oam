#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

check=(ps fax | grep wharf)
if [ ! -z "$check" ];then
	echo "$SERVICE : is still running , will not try to restart"
	exit 0
fi

# configure the service , starting will be automated due to upstart jobs
if [ -f "$OPENEPC_PATH/install/$INSTALL_SYSTEM" ];then
	$OPENEPC_PATH/install/./$INSTALL_SYSTEM -s hss >> $EPC_CONFIGURE_LOG 2>&1
fi



# do not forget to add some users to the database
#if [ -f "$HSS_PROVISION_DIR/$HSS_PROVISION_SCRIPT" ];then
#	if [ ! -z "$HSS_PROVISION_NUMBER" ];then
#		echo "$SERVICE : provisioning $HSS_PROVISION_NUMBER users for hss"
#		cd $HSS_PROVISION_DIR
#		./$HSS_PROVISION_SCRIPT $HSS_PROVISION_PLMN $HSS_PROVISION_SUF $HSS_PROVISION_NUMBER 2>&1 >> $EPC_CONFIGURE_LOG 2>&1
#	fi
#fi

# If there is the 5000 users file from alex, import it
if [ -f "$HSS_PROVISION_DIR/$HSS_PROVISION_DB" ];then
	mysql -u root < $HSS_PROVISION_DIR/$HSS_PROVISION_DB
fi

