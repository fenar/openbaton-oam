#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr


# This script takes care of renaming the network interfaces on the machine according
# to the networks used in openstack taking the configuration paraeters into account.


############# 		 ############# 	
############# Workaround ############# 
#############		 ############# 
if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
fi
#############		############# 
#############		############# 
if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
	echo "$SERVICE : SCRIPTS_PATH was empty, setting it to : $SCRIPTS_PATH"
else
	echo "$SERVICE : SCRIPTS_PATH was not empty : $SCRIPTS_PATH"
fi

minNum=2
udev_persistent_path="/etc/udev/rules.d/70-persistent-net.rules"
interfaces_path="/etc/network/interfaces.d"

# Get a list of potential interfaces for our machine  /  not taking the lxd - bridge into account due to juju-vnfm
INTERFACES=$(ip link ls | gawk 'BEGIN{FS=" ";k=0;}{if (k%2==0) printf("%s\n",$2);k++}END{}' | sed -e "s/:$//" | sed -e "s/lxdbr0/ /g")
# Get the number of interfaces configured by our cloud provider
total_intf_num=$(echo $INTERFACES | wc -w )
# remove the local interface from counting
number_of_network_interfaces=$(echo $total_intf_num -1 | bc )
# list of interfaces which are already available via ifconfig
already_configured_intf=$(ifconfig | grep -v "^[ ]" | awk '{print $1}')

echo "$SERVICE : We got following interfaces available : [ $INTERFACES ], this makes a total of $number_of_network_interfaces without the loopback interface"
echo "$SERVICE : The following interfaces are already configured properly : $already_configured_intf"

# If there are default options load them 

echo "$SERVICE : checking for $SCRIPTS_PATH/default_options"
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi 

numInf="$number_of_network_interfaces"

version=$(cat /etc/os-release | grep VERSION_ID | cut -d "=" -f 2)
echo "$SERVICE : Operating system : $version"
# Lets check it with wildcards
if [[ $version == *"14.04"* ]] || [[ $version == *"16.04"* ]];then
	if [ "$numInf" -lt "$minNum" ]; then
		echo "$SERVICE : Provided number : $numInf is less then the minimal number defined : $minNum , the network interfaces file will not be changed!"
	else
		if [[ $version == *"14.04"* ]];then
			base_net_name="eth"
			start="2"
		elif [[ $version == *"16.04"* ]];then
			base_net_name="ens"
		fi
		start_num=$(ifconfig | grep $base_net_name | awk '{print $1}' | head -n 1 | sed 's/[^0-9]//g')
		if [[ $version == *"16.04"* ]];then
			start=$(echo " 1 + $start_num" | bc )
		fi
		numInf=$(echo "$numInf + $start_num" | bc)
		for i in $(seq $start $numInf)
		do
			z=$(($i-1))
			check=$(echo $already_configured_intf | grep $base_net_name$z )
			# Only if the interfaces are not configured yet, add them
			if [ -z "$check" ];then
				echo "$SERVICE : creating $base_net_name$z interface"
				cat > $interfaces_path/$base_net_name$z.cfg << EOF
auto $base_net_name$z
iface $base_net_name$z inet dhcp
EOF

				# echo source $interfaces_path/$base_net_name$z.cfg  >> /etc/network/interfaces			
			else
				echo "$SERVICE : $base_net_name$z was already configured properly"
			fi
		done
		for i in $(seq $start $numInf)
		do
			echo "$SERVICE : bringing up $base_net_name$z interface"
			z=$(($i-1))
			ifup $base_net_name$z 2>&1
		done
	fi
	# Lets do some mapping via configuration parameters
	if [ ! -z "$mgmt_network_interface" ];then
		echo "$SERVICE : checking for ip on mgmt network : $mgmt"
		if [ ! -z "$mgmt" ];then
			echo "$SERVICE : Checking which interface got the IP : $mgmt"
			local_mgmt_intf=$(ip addr | grep -B 2 "$mgmt" | head -1 | awk '{ print $2 }' | sed 's/://')
			echo "$SERVICE : Local interface to be named $mgmt_network_interface : $local_mgmt_intf"
		fi
	fi
	if [ ! -z "$net_a_network_interface" ];then
		echo "$SERVICE : checking for ip on net_a network : $net_a"
		if [ ! -z "$net_a" ];then
			echo "$SERVICE : Checking which interface got the IP : $net_a"
			local_net_a_intf=$(ip addr | grep -B 2 "$net_a" | head -1 | awk '{ print $2 }' | sed 's/://')
			echo "$SERVICE : Local interface to be named $net_a_network_interface : $local_net_a_intf"
		fi
	fi
	if [ ! -z "$net_b_network_interface" ];then
		echo "$SERVICE : checking for ip on net_b network : $net_c"
		if [ ! -z "$net_b" ];then
			echo "$SERVICE : Checking which interface got the IP : $net_b"
			local_net_b_intf=$(ip addr | grep -B 2 "$net_b" | head -1 | awk '{ print $2 }' | sed 's/://')
			echo "$SERVICE : Local interface to be named $net_b_network_interface : $local_net_b_intf"
		fi
	fi
	if [ ! -z "$net_c_network_interface" ];then
		echo "$SERVICE : checking for ip on net_c network : $net_c"
		if [ ! -z "$net_c" ];then
			echo "$SERVICE : Checking which interface got the IP : $net_c"
			local_net_c_intf=$(ip addr | grep -B 2 "$net_c" | head -1 | awk '{ print $2 }' | sed 's/://')
			echo "$SERVICE : Local interface to be named $net_c_network_interface : $local_net_c_intf"
		fi
	fi
	if [ ! -z "$net_d_network_interface" ];then
		echo "$SERVICE : checking for ip on net_d network : $net_d"
		if [ ! -z "$net_d" ];then
			echo "$SERVICE : Checking which interface got the IP : $net_d"
			local_net_d_intf=$(ip addr | grep -B 2 "$net_d" | head -1 | awk '{ print $2 }' | sed 's/://')
			echo "$SERVICE : Local interface to be named $net_d_network_interface : $local_net_d_intf"
		fi
	fi
	# Check for the current default route 
	old_default_route=$(ip route | grep default)
	old_default_r_intf=$(echo $old_default_route | awk '{print $5}')
	echo "$SERVICE : Old default route is $old_default_route , interface is $old_default_r_intf"
	# Associative arrays are complicated in bash, lets brute force it...
	if [ "$old_default_r_intf" == "$local_mgmt_intf" ];then
		future_default_r_intf=$mgmt_network_interface
	elif [ "$old_default_r_intf" == "$local_net_a_intf" ];then
		future_default_r_intf=$net_a_network_interface
	elif [ "$old_default_r_intf" == "$local_net_b_intf" ];then
		future_default_r_intf=$net_b_network_interface
	elif [ "$old_default_r_intf" == "$local_net_c_intf" ];then
		future_default_r_intf=$net_c_network_interface
	elif [ "$old_default_r_intf" == "$local_net_d_intf" ];then
		future_default_r_intf=$net_d_network_interface
	else
		echo "$SERVICE : Could not restore default route, please check for the defined network names.."
		echo "$SERVICE : mgmt : $local_mgmt_intf ## net_a : $local_net_a_intf ## net_b : $local_net_b_intf ## net_c : $local_net_c_intf ## net_d : $local_net_d_intf"
		exit 1
	fi
	future_default_route=$(echo $old_default_route | sed -e "s/$old_default_r_intf/$future_default_r_intf/g")
	echo "$SERVICE : Future default route will be : $future_default_route"
	# Now that we have created the files and brought up the interfaces , lets rename them
	echo "$SERVICE : Starting to rename interfaces"
	# Allow them to be corrected on reboot / interface up/down
	if [ -f "$interfaces_path/$local_mgmt_intf.cfg" ] && [ ! -z "$local_mgmt_intf" ];then
		echo "$SERVICE : renaming $local_mgmt_intf to $mgmt_network_interface"
		sed -i "s/$local_mgmt_intf/$mgmt_network_interface/g" $interfaces_path/$local_mgmt_intf.cfg
		ifconfig $local_mgmt_intf down  
		ip link set $local_mgmt_intf name $mgmt_network_interface  
		ifconfig $mgmt_network_interface up  
	fi
	if [ -f "$interfaces_path/$local_net_a_intf.cfg" ] && [ ! -z "$local_net_a_intf" ];then
		echo "$SERVICE : renaming $local_net_a_intf to $net_a_network_interface"
		sed -i "s/$local_net_a_intf/$net_a_network_interface/g" $interfaces_path/$local_net_a_intf.cfg
		ifconfig $local_net_a_intf down  
		ip link set $local_net_a_intf name $net_a_network_interface  
		ifconfig $net_a_network_interface up  
	fi
	if [ -f "$interfaces_path/$local_net_b_intf.cfg" ] && [ ! -z "$local_net_b_intf" ];then
		echo "$SERVICE : renaming $local_net_b_intf to $net_b_network_interface"
		sed -i "s/$local_net_b_intf/$net_b_network_interface/g" $interfaces_path/$local_net_b_intf.cfg
		ifconfig $local_net_b_intf down  
		ip link set $local_net_b_intf name $net_b_network_interface  
		ifconfig $net_b_network_interface up  
	fi
	if [ -f "$interfaces_path/$local_net_c_intf.cfg" ] && [ ! -z "$local_net_c_intf" ];then
		echo "$SERVICE : renaming $local_net_c_intf to $net_c_network_interface"
		sed -i "s/$local_net_c_intf/$net_c_network_interface/g" $interfaces_path/$local_net_c_intf.cfg
		ifconfig $local_net_c_intf down  
		ip link set $local_net_c_intf name $net_c_network_interface  
		ifconfig $net_c_network_interface up  
	fi
	if [ -f "$interfaces_path/$local_net_d_intf.cfg" ] && [ ! -z "$local_net_d_intf" ];then
		echo "$SERVICE : renaming $local_net_d_intf to $net_d_network_interface"
		sed -i "s/$local_net_d_intf/$net_d_network_interface/g" $interfaces_path/$local_net_d_intf.cfg
		ifconfig $local_net_d_intf down  
		ip link set $local_net_d_intf name $net_d_network_interface  
		ifconfig $net_d_network_interface up  
	fi
	# Another check for 16.04 
	if [[ $version == *"16.04"* ]];then 
		file="$interfaces_path/50-cloud-init.cfg"
		if [ -f "$file" ];then
			to_be_renamed=$(cat $file | grep ens | cut -d " " -f 2 | head -n 1)
			echo "$SERVICE : Found $to_be_renamed configured in $file"
			if [ "$to_be_renamed" == "$local_mgmt_intf" ];then
				old_inf=$local_mgmt_intf
				new_inf=$mgmt_network_interface
			elif [ "$to_be_renamed" == "$local_net_a_intf" ];then
				old_inf=$local_net_a_intf
				new_inf=$net_a_network_interface
			elif [ "$to_be_renamed" == "$local_net_b_intf" ];then
				old_inf=$local_net_b_intf
				new_inf=$net_b_network_interface
			elif [ "$to_be_renamed" == "$local_net_c_intf" ];then
				old_inf=$local_net_c_intf
				new_inf=$net_c_network_interface
			elif [ "$to_be_renamed" == "$local_net_d_intf" ];then
				old_inf=$local_net_d_intf
				new_inf=$net_d_network_interface
			else
				echo "$SERVICE : could not properly configure all interfaces!"
				exit 1
			fi
			sed -i "s/$old_inf/$new_inf/g" $file
			ifconfig $old_inf down
			ip link set $old_inf name $new_inf
			ifconfig $new_inf up
		fi

	fi

	# Restore the default route which we may have lost during updating the network interface names..
	ip route replace $future_default_route
	# Now also do the step for udev
	for i in $INTERFACES
	do
	    echo "$SERVICE : Working on $i"
	    if [ "$i" != "lo" ]; then
		if [ "$i" == "$local_mgmt_intf" ] && [ ! -z "$local_mgmt_intf" ]; then
			name=$mgmt_network_interface
		elif [ "$i" == "$local_net_a_intf" ] && [ ! -z "$local_net_a_intf" ]; then
			name=$net_a_network_interface
		elif [ "$i" == "$local_net_b_intf" ] && [ ! -z "$local_net_b_intf" ]; then
			name=$net_b_network_interface
		elif [ "$i" == "$local_net_c_intf" ] && [ ! -z "$local_net_c_intf" ]; then
			name=$net_c_network_interface
		elif [ "$i" == "$local_net_d_intf" ] && [ ! -z "$local_net_d_intf" ]; then
			name=$net_d_network_interface
		fi
		mac=$(ifconfig | grep $name | awk '{print $NF}')
		if [ ! -z "$name" ]; then
			echo "$SERVICE : creating udev persitent rule for $name on $mac"
			if [[ $version == *"14.04"* ]];then
				echo "SUBSYSTEM==\"net\", ACTION==\"add\", DRIVERS==\"?*\", ATTR{address}==\"$mac\", KERNEL==\"eth*\", NAME=\"$name\"" >> $udev_persistent_path 
			elif [[ $version == *"16.04"* ]];then
				echo "SUBSYSTEM==\"net\", ACTION==\"add\", DRIVERS==\"?*\", ATTR{address}==\"$mac\", ATTR{dev_id}==\"0x0\", ATTR{type}==\"1\", NAME=\"$name\"" >> $udev_persistent_path
			fi
		fi
	    fi
	done
	echo "" >> $udev_persistent_path 
	
	/etc/init.d/udev restart
	rmmod e1000
	modprobe e1000
	rmmod vmxnet3
	modprobe vmxnet3
	cat $udev_persistent_path 
	ip link ls

else
	echo "$SERVICE : Not supporting the OS : $version , currently only 14.04 and 16.04 are supported..."
	exit 1
fi

