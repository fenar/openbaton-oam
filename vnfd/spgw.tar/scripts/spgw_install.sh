#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# spgw install script

############# 		 ############# 	
############# Workaround ############# 
#############		 ############# 
if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
fi
#############		############# 
#############		############# 

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ];then
	source $SCRIPTS_PATH/$RELATION_BUCKET
fi

if [ -z "$mgmt_network_interface" ];then
	echo "$SERVICE : mgmt_network_interface not defined, will use default : mgmt"
	mgmt_network_interface="mgmt"
fi
if [ -z "$net_a_network_interface" ];then
	echo "$SERVICE : net_a_network_interface not defined, will use default : net_a"
	net_a_network_interface="net_a"
fi
if [ -z "$net_d_network_interface" ];then
	echo "$SERVICE : net_d_network_interface not defined, will use default : net_d"
	net_d_network_interface="net_d"
fi

# Set the correct interface if we have changed the network name..
# We override the default values here
com=mgmt\=\$$mgmt_network_interface
echo "$SERVICE : mgmt ip before check : $mgmt on $mgmt_network_interface"
eval $com
echo "$SERVICE : mgmt ip after check : $mgmt on $mgmt_network_interface"
echo "$SERVICE : mgmt_floatingIp before check : $mgmt_floatingIp on $mgmt_network_interface"
com=mgmt_floatingIp\=\$$mgmt_network_interface\_floatingIp
eval $com
echo "$SERVICE : mgmt_floatingIp after check : $mgmt_floatingIp on $mgmt_network_interface"
echo "$SERVICE : net_a ip before check : $net_a on $net_a_network_interface"
com=net_a\=\$$net_a_network_interface
eval $com
echo "$SERVICE : net_a ip before after : $net_a on $net_a_network_interface"
echo "$SERVICE : net_a_floatingIp before check : $net_a_floatingIp on $net_a_network_interface"
com=net_a_floatingIp\=\$$net_a_network_interface\_floatingIp
eval $com
echo "$SERVICE : net_d_floatingIp after check : $net_d_floatingIp on $net_d_network_interface"
echo "$SERVICE : net_d ip before check : $net_d on $net_d_network_interface"
com=net_d\=\$$net_d_network_interface
eval $com
echo "$SERVICE : net_d ip before after : $net_d on $net_d_network_interface"
echo "$SERVICE : net_d_floatingIp before check : $net_d_floatingIp on $net_d_network_interface"
com=net_d_floatingIp\=\$$net_d_network_interface\_floatingIp
eval $com
echo "$SERVICE : net_d_floatingIp after check : $net_d_floatingIp on $net_d_network_interface"

#while [ -z "$ipv6_net_a_complete" ]
#do
#	echo "$SERVICE : Checking for net_a ipv6 address"
#	ipv6_net_a_complete=$(ifconfig $net_a_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#	if [ -z "$ipv6_net_a_complete" ];then
#		# If the Global scope is not available, use the link scope
#		ipv6_net_a_complete=$(ifconfig $net_a_network_interface | grep "inet6 addr" | grep "Link" | awk '{print $3}')
#	fi
#	sleep 8s
#done

#ipv6_net_a_ip=$(echo $ipv6_net_a_complete | cut -d "/" -f 1)
#ipv6_net_a_prefix=$(echo $ipv6_net_a_complete | cut -d "/" -f 2)

#while [ -z "$ipv6_net_a_complete" ]
#do
#	echo "$SERVICE : Checking for net_d ipv6 address"
#	ipv6_net_d_complete=$(ifconfig $net_d_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#	if [ -z "$ipv6_net_d_complete" ];then
#		# If the Global scope is not available, use the link scope
#		ipv6_net_d_complete=$(ifconfig $net_d_network_interface | grep "inet6 addr" | grep "Link" | awk '{print $3}')
#	fi
#	sleep 8s
#done

#ipv6_net_d_ip=$(echo $ipv6_net_d_complete | cut -d "/" -f 1)
#ipv6_net_d_prefix=$(echo $ipv6_net_d_complete | cut -d "/" -f 2)

# Substitute the related values in the data_topology_vars.sh file ( for enbm )
if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*spgw_mgmt_ipv4=.*/spgw_mgmt_ipv4=\"$mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	# spgw_mgmt_prefixv4="$spgw_mgmt_ipv4/24"
	cat $DATA_TOP | sed "s/\.*spgw_net_a_ipv4=.*/spgw_net_a_ipv4=\"$net_a\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	# spgw_net_a_prefixv4="$spgw_net_a_ipv4/24"
	cat $DATA_TOP | sed "s/\.*spgw_net_d_ipv4=.*/spgw_net_d_ipv4=\"$net_d\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	# spgw_net_d_prefixv6="$spgw_net_d_ipv6/112"
	#cat $DATA_TOP | sed "s/\.*spgw_net_a_ipv6=.*/spgw_net_a_ipv6=\"$ipv6_net_a_ip\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*spgw_net_a_prefixv6.*/spgw_net_a_prefixv6=\"\$spgw_net_a_ipv6\/$ipv6_net_d_prefix\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*spgw_net_d_ipv6=.*/spgw_net_d_ipv6=\"$ipv6_net_d_ip\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*spgw_net_d_prefixv6.*/spgw_net_d_prefixv6=\"\$spgw_net_d_ipv6\/$ipv6_net_d_prefix\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	# What about : spgw_net_a_gateway="$inetgw_net_a_ipv4"
fi

if [ -f "$IP_RANGE" ];then
	cat $IP_RANGE | sed "s/\.*data__pdn_ops__pdn_ipv4_range__1__start=.*/data__pdn_ops__pdn_ipv4_range__1__start=\"$IP_START\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $IP_RANGE
	cat $IP_RANGE | sed "s/\.*data__pdn_ops__pdn_ipv4_range__1__end=.*/data__pdn_ops__pdn_ipv4_range__1__end=\"$IP_END\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $IP_RANGE
	cat $IP_RANGE | sed "s/\.*data__pdn_ops__pdn_ipv4_range__1__mask=.*/data__pdn_ops__pdn_ipv4_range__1__mask=\"$IP_MASK\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $IP_RANGE
	cat $IP_RANGE | sed "s/\.*data__pdn_ops__pdn_ipv4_range__1__network=.*/data__pdn_ops__pdn_ipv4_range__1__network=\"$IP_NET\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $IP_RANGE
fi 
