#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# spgw powerdns relation joined script

############# 		 ############# 	
############# Workaround ############# 
#############		 ############# 
if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
fi
#############		############# 
#############		############# 

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

if [ -z "$powerdns_mgmt_network_interface" ];then
	echo "$SERVICE : powerdns_mgmt_network_interface not defined, will use default : mgmt"
	powerdns_mgmt_network_interface="mgmt"
fi

if [ -z "$powerdns_net_a_network_interface" ];then
	echo "$SERVICE : powerdns_net_a_network_interface not defined, will use default : net_a"
	powerdns_net_a_network_interface="net_a"
fi

# Set the correct interface if we have changed the network names
com=powerdns_ip_mgmt\=\$powerdns_$powerdns_mgmt_network_interface
eval $com
com=powerdns_floating_ip_mgmt\=\$powerdns_$powerdns_mgmt_network_interface\_floatingIp
eval $com
com=powerdns_ip_net_a\=\$powerdns_$powerdns_net_a_network_interface
eval $com
com=powerdns_floating_ip_net_a\=\$powerdns_$powerdns_net_a_network_interface\_floatingIp
eval $com


# First step is to check if we have already set up the nameserver
check=$(cat /etc/resolv.conf | grep $powerdns_realm )
if [ ! -z "$check" ];then
	echo "$SERVICE : We already added a relation to powerdns! Will not do anything"
	exit 0
fi


# Well , openbaton yet does not give us the ipv6 addresses, thus we need to leave out this part...
# dns_net_a_ipv6
# dns_net_a_prefixv6

if [ -z "$powerdns_ip_mgmt" ];then
	echo "$SERVICE : powerdns has not ip on network $powerdns_mgmt_network_interface !"
	exit 1
fi

if [ -z "$powerdns_ip_net_a" ];then
	echo "$SERVICE : powerdns has not ip on network $powerdns_net_a_network_interface !"
	exit 1
fi

# TODO : Still we do not check if we even have a floating Ip on the related networks!!
if [ -f "$DATA_TOP" ];then
#	if [  "$powerdns_useFloatingIpsForEntries" != "false" ];then
#		cat $DATA_TOP | sed "s/\.*dns_mgmt_ipv4=.*/dns_mgmt_ipv4=\"$powerdns_floating_ip_mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
#		cat $DATA_TOP | sed "s/\.*dns_net_a_ipv4=.*/dns_net_a_ipv4=\"$powerdns_floating_ip_net_a\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
#	else 
		cat $DATA_TOP | sed "s/\.*dns_mgmt_ipv4=.*/dns_mgmt_ipv4=\"$powerdns_ip_mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
		cat $DATA_TOP | sed "s/\.*dns_net_a_ipv4=.*/dns_net_a_ipv4=\"$powerdns_ip_net_a\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
#	fi
fi

# Adding the nameserver quite hacky, simply pass our stuff into the head and base file
# For the spgw we only have to check for the mgmt 
#if [ -f "$RESOLV_HEAD" ] && [ -f "$RESOLV_BASE" ];then
#	if [  "$powerdns_useFloatingIpsForEntries" != "false" ];then
#		if [ ! z "$powerdns_floating_ip_mgmt" ];then
#			echo "nameserver $powerdns_floating_ip_mgmt" >> $RESOLV_HEAD
#		else
#			echo "nameserver $powerdns_ip_mgmt" >> $RESOLV_HEAD
#		fi
#	else
#		echo "nameserver $powerdns_ip_mgmt" >> $RESOLV_HEAD
#	fi
#
#	echo "search $powerdns_realm" >> $RESOLV_BASE
#fi

# force reloading
#resolvconf -u

# Save all IPs, the ones we get from openbaton + the ones we calculated,
# so we may afterwards check if the networks have been renamed
printf "powerdns_mgmt=%s\n" \"$powerdns_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "powerdns_ip_mgmt=%s\n" \"$powerdns_ip_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "powerdns_mgmt_floatingIp=%s\n" \"$powerdns_mgmt_floatingIp\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "powerdns_floating_ip_mgmt=%s\n" \"$powerdns_floating_ip_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
# Still we do need take the realm from powerdns since OpenEPC itself handles the realm in parts
printf "powerdns_realm=%s\n" \"$powerdns_realm\" >> $SCRIPTS_PATH/$RELATION_BUCKET

#printf "powerdns_useFloatingIpsForEntries=%s\n" \"$powerdns_useFloatingIpsForEntries\" >> $SCRIPTS_PATH/$RELATION_BUCKET


