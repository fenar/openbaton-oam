#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

check=$(ps fax | grep wharf | grep xml)
if [ ! -z "$check" ];then
	echo "$SERVICE : is still running , will not try to restart"
	exit 0
fi

# configure the service , starting will be automated due to upstart jobs
if [ -f "$OPENEPC_PATH/install/$INSTALL_SYSTEM" ];then
	$OPENEPC_PATH/install/./$INSTALL_SYSTEM -s enodeb -e multiple >> $EPC_CONFIGURE_LOG 2>&1
fi

