#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# enbm install script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ];then
	source $SCRIPTS_PATH/$RELATION_BUCKET
fi

if [ -z "$mgmt_network_interface" ];then
	echo "$SERVICE : mgmt_network_interface not defined, will use default : mgmt"
	mgmt_network_interface="mgmt"
fi
if [ -z "$net_c_network_interface" ];then
	echo "$SERVICE : net_c_network_interface not defined, will use default : net_c"
	net_c_network_interface="net_c"
fi
if [ -z "$net_d_network_interface" ];then
	echo "$SERVICE : net_d_network_interface not defined, will use default : net_d"
	net_d_network_interface="net_d"
fi

# Set the correct interface if we have changed the network name..
# We override the default values here
com=mgmt\=\$$mgmt_network_interface
echo "$SERVICE : mgmt ip before check : $mgmt on $mgmt_network_interface"
eval $com
echo "$SERVICE : mgmt ip after check : $mgmt on $mgmt_network_interface"
echo "$SERVICE : mgmt_floatingIp before check : $mgmt_floatingIp on $mgmt_network_interface"
com=mgmt_floatingIp\=\$$mgmt_network_interface\_floatingIp
eval $com
echo "$SERVICE : mgmt_floatingIp after check : $mgmt_floatingIp on $mgmt_network_interface"
echo "$SERVICE : net_c ip before check : $net_c on $net_c_network_interface"
com=net_c\=\$$net_c_network_interface
eval $com
echo "$SERVICE : net_c ip before after : $net_c on $net_c_network_interface"
echo "$SERVICE : net_c_floatingIp before check : $net_c_floatingIp on $net_c_network_interface"
com=net_c_floatingIp\=\$$net_c_network_interface\_floatingIp
eval $com
echo "$SERVICE : net_d_floatingIp after check : $net_d_floatingIp on $net_d_network_interface"
echo "$SERVICE : net_d ip before check : $net_d on $net_d_network_interface"
com=net_d\=\$$net_d_network_interface
eval $com
echo "$SERVICE : net_d ip before after : $net_d on $net_d_network_interface"
echo "$SERVICE : net_d_floatingIp before check : $net_d_floatingIp on $net_d_network_interface"
com=net_d_floatingIp\=\$$net_d_network_interface\_floatingIp
eval $com
echo "$SERVICE : net_d_floatingIp after check : $net_d_floatingIp on $net_d_network_interface"


#while [ -z "$ipv6_net_c_complete" ]
#do
#	echo "$SERVICE : Checking for net_c ipv6 address"
#	ipv6_net_c_complete=$(ifconfig $net_c_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#	if [ -z "$ipv6_net_c_complete" ];then
#		# If the Global scope is not available, use the link scope
#		ipv6_net_c_complete=$(ifconfig $net_c_network_interface | grep "inet6 addr" | grep "Link" | awk '{print $3}')
#	fi
#	sleep 8s
#done

#ipv6_net_c_ip=$(echo $ipv6_net_c_complete | cut -d "/" -f 1)
#ipv6_net_c_prefix=$(echo $ipv6_net_c_complete | cut -d "/" -f 2)

#while [ -z "$ipv6_net_d_complete" ]
#do
#	echo "$SERVICE : Checking for net_d ipv6 address"
#	ipv6_net_d_complete=$(ifconfig $net_d_network_interface | grep "inet6 addr" | grep "Global" | awk '{print $3}')
#	if [ -z "$ipv6_net_d_complete" ];then
#		# If the Global scope is not available, use the link scope
#		ipv6_net_d_complete=$(ifconfig $net_d_network_interface | grep "inet6 addr" | grep "Link" | awk '{print $3}')
#	fi
#	sleep 8s
#done

#ipv6_net_d_ip=$(echo $ipv6_net_d_complete | cut -d "/" -f 1)
#ipv6_net_d_prefix=$(echo $ipv6_net_d_complete | cut -d "/" -f 2)



# Substitute the related values in the data_topology_vars.sh file ( for enbm )
if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*enodeb_mgmt_ipv4=.*/enodeb_mgmt_ipv4=\"$mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	# enodeb_mgmt_prefixv4="$enodeb_mgmt_ipv4/24"
	cat $DATA_TOP | sed "s/\.*enodeb_net_c_ipv4=.*/enodeb_net_c_ipv4=\"$net_c\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	# enodeb_net_c_prefixv4="$enodeb_net_c_ipv4/32"
	cat $DATA_TOP | sed "s/\.*enodeb_net_d_ipv4=.*/enodeb_net_d_ipv4=\"$net_d\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	# enodeb_net_d_prefixv4="$enodeb_net_d_ipv4/24"
	#cat $DATA_TOP | sed "s/\.*enodeb_net_c_ipv6=.*/enodeb_net_c_ipv6=\"$ipv6_net_c_ip\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*enodeb_net_c_prefixv6.*/enodeb_net_c_prefixv6=\"\$enodeb_net_c_ipv6\/$ipv6_net_c_prefix\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP

	#cat $DATA_TOP | sed "s/\.*enodeb_net_d_ipv6=.*/enodeb_net_d_ipv6=\"$ipv6_net_d_ip\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	#cat $DATA_TOP | sed "s/\.*enodeb_net_d_prefixv6.*/enodeb_net_d_prefixv6=\"\$enodeb_net_d_ipv6\/$ipv6_net_d_prefix\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi

if [ -f "$SCRIPTS_PATH/$ATTACH_SCRIPT" ];then
	cat $SCRIPTS_PATH/$ATTACH_SCRIPT | sed "s/VAR_ENODEB_MGMT/$mgmt/g" > $TMP_FILE && mv $TMP_FILE $SCRIPTS_PATH/$ATTACH_SCRIPT
	cp $SCRIPTS_PATH/$ATTACH_SCRIPT /home/ubuntu/$ATTACH_SCRIPT
	chmod +x /home/ubuntu/$ATTACH_SCRIPT
	cat $SCRIPTS_PATH/$DETACH_SCRIPT | sed "s/VAR_ENODEB_MGMT/$mgmt/g" > $TMP_FILE && mv $TMP_FILE $SCRIPTS_PATH/$DETACH_SCRIPT
	cp $SCRIPTS_PATH/$DETACH_SCRIPT /home/ubuntu/$DETACH_SCRIPT
	chmod +x /home/ubuntu/$DETACH_SCRIPT
fi



