#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# enbm mme relation joined script
# Get the ips from mgmt and net_d network and save them for later usage

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

if [ -z "$mme_mgmt_network_interface" ];then
	echo "$SERVICE : mme_mgmt_network_interface not defined, will use default : mgmt"
	mme_mgmt_network_interface="mgmt"
fi
if [ -z "$mme_net_d_network_interface" ];then
	echo "$SERVICE : mme_net_d_network_interface not defined, will use default : net_d"
	mme_net_d_network_interface="net_d"
fi

# Set the correct interface if we have changed the network names
com=mme_ip_mgmt\=\$mme_$mme_mgmt_network_interface
eval $com
com=mme_floating_ip_mgmt\=\$mme_$mme_mgmt_network_interface\_floatingIp
eval $com
com=mme_ip_net_d\=\$mme_$mme_net_d_network_interface
eval $com
com=mme_floating_ip_net_d\=\$mme_$mme_net_d_network_interface\_floatingIp
eval $com


if [ -z "$mme_ip_mgmt" ];then
	echo "$SERVICE : mme has not ip on network $mme_mgmt_network_interface !"
	exit 1
fi
if [ -z "$mme_ip_net_d" ];then
	echo "$SERVICE : mme has not ip on network $mme_net_d_network_interface !"
	exit 1
fi

# Replace the information in the data_topology_vars.sh file which is needed for the enbm
# We cannot replace the ipv6 related information of the mme since we just do not get it from openbaton

#################################################################################################
# If we would need additional informations we should try to get all values from the powerdns	#
# in the START_LIFECYCLE and not substitute them in the relation scripts			#
#################################################################################################
if [ -f "$DATA_TOP" ];then
	cat $DATA_TOP | sed "s/\.*mme_mgmt_ipv4=.*/mme_mgmt_ipv4=\"$mme_ip_mgmt\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
	cat $DATA_TOP | sed "s/\.*mme_net_d_ipv4=.*/mme_net_d_ipv4=\"$mme_ip_net_d\" # openbaton-generated/" > $TMP_FILE && mv $TMP_FILE $DATA_TOP
fi

# Save all IPs, the ones we get from openbaton + the ones we calculated,
# so we may afterwards check if the networks have been renamed
printf "mme_mgmt=%s\n" \"$mme_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_ip_mgmt=%s\n" \"$mme_ip_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_mgmt_floatingIp=%s\n" \"$mme_mgmt_floatingIp\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_floating_ip_mgmt=%s\n" \"$mme_floating_ip_mgmt\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_net_d=%s\n" \"$mme_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_ip_net_d=%s\n" \"$mme_ip_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_net_d_floatingIp=%s\n" \"$mme_net_d_floatingIp\" >> $SCRIPTS_PATH/$RELATION_BUCKET
printf "mme_floating_ip_net_d=%s\n" \"$mme_floating_ip_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET
