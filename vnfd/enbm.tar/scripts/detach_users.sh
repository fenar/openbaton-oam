#!/bin/bash

# we take the information of the currently connected spgw and save the imsis related to it

# how many users to detach on each spgw
detach_num="10"

if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
fi
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi
if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ]; then
	source $SCRIPTS_PATH/$RELATION_BUCKET
fi

# Get all connected switches
sp_imsi_list=$(ls $SCRIPTS_PATH | grep "spgw-" )
echo "found : $sp_imsi_list"

# Now for all of them go inside and detach a few
# thus we are detaching from all spgws
for spgw in $SCRIPTS_PATH/*; do
	echo "checking :  $spgw"
	check=$(echo $spgw | grep "spgw-")
	if [ ! -z "$check" ];then
		echo "found spgw : $spgw"
	        imsis_tobe_detached=$(head -n $detach_num $spgw)
        	echo "detaching $imsis_tobe_detached"
        	while read -r curr_imsi;
        	do
               		echo enodeb.detach $curr_imsi | nc VAR_ENODEB_MGMT 10000
			sed -i "/$curr_imsi/d" $spgw
        	done <<< "$imsis_tobe_detached"
	fi
done
# In the end the users on a spgw can be empty, anyway the files are only removed when the related instance is scaled in
