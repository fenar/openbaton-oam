#!/bin/bash

# we take the information of the currently connected spgw and save the imsis related to it

# how many users to detach on each spgw
detach_num="10"

if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
fi
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi
if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ]; then
	source $SCRIPTS_PATH/$RELATION_BUCKET
fi

# Get all connected switches
sp_imsi_list=$(ls $SCRIPTS_PATH | grep "spgw-" )

# Now for all of them go inside and detach a few
# thus we are detaching from all spgws
for spgw in $ $sp_imsi_list
do
	imsis_tobe_detached=$(head -n $detach_num)
	while read -r curr_imsi;
	do
		echo enodeb.detach $curr_imsi | nc VAR_ENODEB_MGMT 10000
	done <<< "$imsis_tobe_detached"
done
# In the end the users on a spgw can be empty, anyway the files are only removed when the related instance is scaled in
