#!/bin/bash

# we take the information of the currently connected spgw and save the imsis related to it

if [ -z "$SCRIPTS_PATH" ];then
	SCRIPTS_PATH="/opt/openbaton/scripts"
fi
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi
if [ -f "$SCRIPTS_PATH/$RELATION_BUCKET" ]; then
	source $SCRIPTS_PATH/$RELATION_BUCKET
fi
# The current spgw is now : spgw_hostname
spgw_hostname=$(cat $SCRIPTS_PATH/$RELATION_BUCKET | grep "spgw-" | cut -d "=" -f 1)
echo "Attaching on $spgw_hostname"


# A file where we will simply throw our imsis into
filename="$SCRIPTS_PATH/$spgw_hostname"

IMSI_START="001011234567890"

TOTAL_NUM="50"
STEPSIZE="5"

STEP_NUM=$(echo "$TOTAL_NUM / $STEPSIZE" | bc )

IM_ST=$IMSI_START

for s in $(seq -w 1 $STEP_NUM);
do
        for i in $(seq -w $IM_ST $(echo "$IM_ST + $STEPSIZE" | bc ));
        do
		echo enodeb.attach_many $i | nc VAR_ENODEB_MGMT 10000
		# just append the imsis , so afterwards the scale in script may use this file to detach all users from it
		echo $i >> $filename
        done
        sleep 3s
        # Update the new starting imsi
        IM_ST=00$(echo "$IM_ST + $STEPSIZE +1" | bc )
done

# Update itself to be able to run another time 
if [ -f "/home/ubuntu/attach_users.sh" ];then
	cat /home/ubuntu/attach_users.sh | sed "s/\.*IMSI_START=\"00.*/IMSI_START=\"$IM_ST\"/" > /tmp/tmp.txt && mv /tmp/tmp.txt /home/ubuntu/attach_users.sh
	chmod +x /home/ubuntu/attach_users.sh
fi
