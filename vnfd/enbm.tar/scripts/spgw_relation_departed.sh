#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# enbm spgw relation departed script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi

# All we need to do is check for the hostname ( meaning which switch is scaled in )
# and trigger the detachment of all its users which are connected to this switch


# If we have users connected to the spgw which will be removed, detach them
if [ -f "$SCRIPTS_PATH/$removing_hostname" ];then

	while read imsi; do
		echo enodeb.detach $imsi | nc $mgmt 10000
		sleep 0.5s
	done < $SCRIPTS_PATH/$spgw_hostname
	# in the end delete the file
	rm $SCRIPTS_PATH/$spgw_hostname
fi





