#!/bin/bash
#########################
#	Openbaton	#
#########################
# Author : lgr

# enodeb spgw relation joined script

# If there are default options load them 
if [ -f "$SCRIPTS_PATH/default_options" ]; then
	source $SCRIPTS_PATH/default_options
fi


# All we want to keep track is of the current used spgw
# so that we always know which imsis are connected to which spgw...


# remove the old entry, easily replace it with the new one
sed -i "/$spgw_hostname/d" $SCRIPTS_PATH/$RELATION_BUCKET
printf "$spgw_hostname=%s\n" \"$spgw_net_d\" >> $SCRIPTS_PATH/$RELATION_BUCKET


# so the attach users script now can take this information when attaching imsis


