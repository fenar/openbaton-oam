--
-- Current Database: `powerdns`
--

USE `powerdns`;

--
-- Dumping data for table `cryptokeys`
--

LOCK TABLES `cryptokeys` WRITE;
/*!40000 ALTER TABLE `cryptokeys` DISABLE KEYS */;
/*!40000 ALTER TABLE `cryptokeys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `domainmetadata`
--

LOCK TABLES `domainmetadata` WRITE;
/*!40000 ALTER TABLE `domainmetadata` DISABLE KEYS */;
/*!40000 ALTER TABLE `domainmetadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `domains`
--

LOCK TABLES `domains` WRITE;
/*!40000 ALTER TABLE `domains` DISABLE KEYS */;
INSERT INTO `domains` (id, name, type) VALUES
  (1,     'localhost',                  'NATIVE'),
  (2,     '0.in-addr.arpa',             'NATIVE'),
  (3,     '127.in-addr.arpa',           'NATIVE'),
  (4,     '255.in-addr.arpa',           'NATIVE'),
  (1001,  '1.168.192.in-addr.arpa',     'NATIVE'),
  (1002,  '2.168.192.in-addr.arpa',     'NATIVE'),
  (1003,  '3.168.192.in-addr.arpa',     'NATIVE'),
  (1004,  '4.168.192.in-addr.arpa',     'NATIVE'),
  (1254,  '254.168.192.in-addr.arpa',   'NATIVE'),
  (10000, '%base_realm',                'NATIVE'),
  (10001, '%visited_realm',             'NATIVE'),
  (20000, '%ims_realm',                 'NATIVE'),
  (30000, 'openepc.test',               'NATIVE');
/*!40000 ALTER TABLE `domains` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `records`
--

LOCK TABLES `records` WRITE;
/*!40000 ALTER TABLE `records` DISABLE KEYS */;

-- localhost
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (1,'localhost','SOA',         'localhost. root.localhost. 2 3600 3600 2419200 3600',  3600,1),
  (1,'localhost','NS',          'localhost',                                            3600,1),
  (1,'localhost','A',           '127.0.0.1',                                            3600,1),
  (1,'localhost','AAAA',        '::1',                                                  3600,1);

-- 0.in-addr.arpa
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (2,'0.in-addr.arpa','SOA',    'localhost. root.localhost. 1 3600 3600 2419200 3600',  3600,1),
  (2,'0.in-addr.arpa','NS',     'localhost',                                            3600,1);

-- 127.in-addr.arpa
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (3,'127.in-addr.arpa',        'SOA',  'localhost. root.localhost. 1 3600 3600 2419200 3600',3600,1),
  (3,'127.in-addr.arpa',        'NS',   'localhost',                                          3600,1),
  (3,'1.0.0.127.in-addr.arpa',  'PTR',  'localhost',                                          3600,1),
  (3,'0.0.127.in-addr.arpa',    NULL,   NULL,                                                 NULL,1),
  (3,'0.127.in-addr.arpa',      NULL,   NULL,                                                 NULL,1);

-- 255.in-addr.arpa
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (4,'255.in-addr.arpa','SOA',   'localhost. root.localhost. 1 3600 3600 2419200 3600',3600,1),
  (4,'255.in-addr.arpa','NS',    'localhost',3600,1);


-- net_a - 1.168.192.in-addr.arpa
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (1001,'1.168.192.in-addr.arpa',     'SOA','localhost. root.localhost. 2009110416 10800 900 3600 3600',3600,1),
  (1001,'1.168.192.in-addr.arpa',     'NS', 'ns.%base_realm',             3600,1),
  (1001,'10.1.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',           3600,1),
  (1001,'11.1.168.192.in-addr.arpa',  'PTR','pgw.%base_realm',            3600,1),
  (1001,'12.1.168.192.in-addr.arpa',  'PTR','pgwc.%base_realm',           3600,1),
  (1001,'13.1.168.192.in-addr.arpa',  'PTR','pgwu.%base_realm',           3600,1),
  (1001,'31.1.168.192.in-addr.arpa',  'PTR','andsf.%base_realm',          3600,1),
  (1001,'32.1.168.192.in-addr.arpa',  'PTR','www.%base_realm',            3600,1),
  (1001,'40.1.168.192.in-addr.arpa',  'PTR','dns.%base_realm',            3600,1),
  (1001,'41.1.168.192.in-addr.arpa',  'PTR','mdf.%base_realm',            3600,1),
  (1001,'42.1.168.192.in-addr.arpa',  'PTR','http-proxy.%base_realm',     3600,1),
  (1001,'45.1.168.192.in-addr.arpa',  'PTR','pcscf.%ims_realm',           3600,1),
  (1001,'46.1.168.192.in-addr.arpa',  'PTR','icscf.%ims_realm',           3600,1),
  (1001,'47.1.168.192.in-addr.arpa',  'PTR','scscf.%ims_realm',           3600,1),
  (1001,'49.1.168.192.in-addr.arpa',  'PTR','smsc.%ims_realm',            3600,1),
  (1001,'70.1.168.192.in-addr.arpa',  'PTR','inetgw.%ims_realm',          3600,1),
  (1001,'130.1.168.192.in-addr.arpa', 'PTR','msc.%ims_realm',             3600,1),
  (1001,'180.1.168.192.in-addr.arpa', 'PTR','sms-router.%ims_realm',      3600,1),
  (1001,'*.1.168.192.in-addr.arpa',   'PTR','other-net-a.%base_realm',    3600,1);

-- net_b - 2.168.192.in-addr.arpa
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (1002,'2.168.192.in-addr.arpa',     'SOA','localhost. root.localhost. 2009111 10800 900 3600 3600',3600,1),
  (1002,'2.168.192.in-addr.arpa',     'NS', 'ns.%base_realm',           3600,1),
  (1002,'10.2.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',         3600,1),
  (1002,'11.2.168.192.in-addr.arpa',  'PTR','pgw.%base_realm',          3600,1),
  (1002,'12.2.168.192.in-addr.arpa',  'PTR','pgwc.%base_realm',         3600,1),
  (1002,'13.2.168.192.in-addr.arpa',  'PTR','pgwu.%base_realm',         3600,1),
  (1002,'20.2.168.192.in-addr.arpa',  'PTR','sgw.%base_realm',          3600,1),
  (1002,'21.2.168.192.in-addr.arpa',  'PTR','sgwc.%base_realm',         3600,1),
  (1002,'22.2.168.192.in-addr.arpa',  'PTR','sgwu.%base_realm',         3600,1),
  (1002,'23.2.168.192.in-addr.arpa',  'PTR','twag.%base_realm',         3600,1),
  (1002,'24.2.168.192.in-addr.arpa',  'PTR','epdg.%base_realm',         3600,1),
  (1002,'25.2.168.192.in-addr.arpa',  'PTR','angw.%base_realm',         3600,1),
  (1002,'*.2.168.192.in-addr.arpa',   'PTR','other-net-b.%base_realm',  3600,1);

-- net_c - 3.168.192.in-addr.arpa
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (1003,'3.168.192.in-addr.arpa',     'SOA','localhost. root.localhost. 2009113 10800 900 3600 3600',3600,1),
  (1003,'3.168.192.in-addr.arpa',     'NS','ns.%base_realm',        3600,1),
  (1003,'23.3.168.192.in-addr.arpa',  'PTR','twag.%base_realm',     3600,1),
  (1003,'24.3.168.192.in-addr.arpa',  'PTR','epdg.%base_realm',     3600,1),
  (1003,'25.3.168.192.in-addr.arpa',  'PTR','angw.%base_realm',     3600,1),
  (1003,'28.3.168.192.in-addr.arpa',  'PTR','nodeb.%base_realm',    3600,1),
  (1003,'29.3.168.192.in-addr.arpa',  'PTR','enodeb.%base_realm',   3600,1),
  (1003,'30.3.168.192.in-addr.arpa',  'PTR','enodeb2.%base_realm',  3600,1),
  (1003,'*.3.168.192.in-addr.arpa',   'PTR','ue.%base_realm',       3600,1);

-- net_d - 4.168.192.in-addr.arpa
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (1004,'4.168.192.in-addr.arpa',     'SOA','localhost. root.localhost. 20120611 10800 900 3600 3600',3600,1),
  (1004,'4.168.192.in-addr.arpa',     'NS','ns.%base_realm',            3600,1),
  (1004,'10.4.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',         3600,1),
  (1004,'20.4.168.192.in-addr.arpa',  'PTR','sgw.%base_realm',          3600,1),
  (1004,'21.4.168.192.in-addr.arpa',  'PTR','sgwc.%base_realm',         3600,1),
  (1004,'22.4.168.192.in-addr.arpa',  'PTR','sgwu.%base_realm',         3600,1),
  (1004,'80.4.168.192.in-addr.arpa',  'PTR','mme.%base_realm',          3600,1),
  (1004,'81.4.168.192.in-addr.arpa',  'PTR','mme2.%base_realm',         3600,1),
  (1004,'90.4.168.192.in-addr.arpa',  'PTR','enodeb.%base_realm',       3600,1),
  (1004,'91.4.168.192.in-addr.arpa',  'PTR','enodeb2.%base_realm',      3600,1),
  (1004,'110.4.168.192.in-addr.arpa', 'PTR','nodeb.%base_realm',        3600,1),
  (1004,'120.4.168.192.in-addr.arpa', 'PTR','sgsn.%base_realm',         3600,1),
  (1004,'130.4.168.192.in-addr.arpa', 'PTR','msc.%base_realm',          3600,1),
  (1004,'150.4.168.192.in-addr.arpa', 'PTR','hnbgw.%base_realm',        3600,1),
  (1004,'141.4.168.192.in-addr.arpa', 'PTR','bts.%base_realm',          3600,1),
  (1004,'*.4.168.192.in-addr.arpa',   'PTR','other-net-d.%base_realm',  3600,1);

-- mgmt - 254.168.192.in-addr.arpa'
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (1254,'254.168.192.in-addr.arpa',     'SOA','localhost. root.localhost. 2009112 10800 900 3600 3600',3600,1),
  (1254,'254.168.192.in-addr.arpa',     'NS', 'ns.%base_realm',             3600,1),
  (1254,'1.254.168.192.in-addr.arpa',   'NS', 'vmhost.%base_realm',         3600,1),
  (1254,'2.254.168.192.in-addr.arpa',   'PTR','nat.%base_realm',            3600,1),
  (1254,'10.254.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',           3600,1),
  (1254,'11.254.168.192.in-addr.arpa',  'PTR','pgw.%base_realm',            3600,1),
  (1254,'12.254.168.192.in-addr.arpa',  'PTR','pgwc.%base_realm',           3600,1),
  (1254,'13.254.168.192.in-addr.arpa',  'PTR','pgwu.%base_realm',           3600,1),
  (1254,'20.254.168.192.in-addr.arpa',  'PTR','sgw.%base_realm',            3600,1),
  (1254,'21.254.168.192.in-addr.arpa',  'PTR','sgwc.%base_realm',           3600,1),
  (1254,'22.254.168.192.in-addr.arpa',  'PTR','sgwu.%base_realm',           3600,1),
  (1254,'23.254.168.192.in-addr.arpa',  'PTR','twag.%base_realm',           3600,1),
  (1254,'24.254.168.192.in-addr.arpa',  'PTR','epdg.%base_realm',           3600,1),
  (1254,'25.254.168.192.in-addr.arpa',  'PTR','angw.%base_realm',           3600,1),
  (1254,'30.254.168.192.in-addr.arpa',  'PTR','pcrf.%base_realm',           3600,1),
  (1254,'31.254.168.192.in-addr.arpa',  'PTR','andsf.%base_realm',          3600,1),
  (1254,'32.254.168.192.in-addr.arpa',  'PTR','www.%base_realm',            3600,1),
  (1254,'33.254.168.192.in-addr.arpa',  'PTR','hss.%base_realm',            3600,1),
  (1254,'40.254.168.192.in-addr.arpa',  'PTR','dns.%base_realm',            3600,1),
  (1254,'41.254.168.192.in-addr.arpa',  'PTR','mdf.%base_realm',            3600,1),
  (1254,'42.254.168.192.in-addr.arpa',  'PTR','http-proxy-rx.%base_realm',  3600,1),
  (1254,'45.254.168.192.in-addr.arpa',  'PTR','pcscf-aaa.%ims_realm',       3600,1),
  (1254,'46.254.168.192.in-addr.arpa',  'PTR','icscf-aaa.%ims_realm',       3600,1),
  (1254,'47.254.168.192.in-addr.arpa',  'PTR','scscf-aaa.%ims_realm',       3600,1),
  (1254,'49.254.168.192.in-addr.arpa',  'PTR','smsc.%ims_realm',            3600,1),
  (1254,'50.254.168.192.in-addr.arpa',  'PTR','cdf.%base_realm',            3600,1),
  (1254,'51.254.168.192.in-addr.arpa',  'PTR','cgf.%base_realm',            3600,1),
  (1254,'52.254.168.192.in-addr.arpa',  'PTR','bf.%base_realm',             3600,1),
  (1254,'53.254.168.192.in-addr.arpa',  'PTR','ocs.%base_realm',            3600,1),
  (1254,'70.254.168.192.in-addr.arpa',  'PTR','inetgw.%base_realm',         3600,1),
  (1254,'71.254.168.192.in-addr.arpa',  'PTR','aaa-server.%base_realm',     3600,1),
  (1254,'72.254.168.192.in-addr.arpa',  'PTR','aaa-proxy.%base_realm',      3600,1),
  (1254,'80.254.168.192.in-addr.arpa',  'PTR','mme.%base_realm',            3600,1),
  (1254,'81.254.168.192.in-addr.arpa',  'PTR','mme2.%base_realm',           3600,1),
  (1254,'90.254.168.192.in-addr.arpa',  'PTR','enodeb.%base_realm',         3600,1),
  (1254,'91.254.168.192.in-addr.arpa',  'PTR','enodeb2.%base_realm',        3600,1),
  (1254,'110.254.168.192.in-addr.arpa', 'PTR','nodeb.%base_realm',          3600,1),
  (1254,'120.254.168.192.in-addr.arpa', 'PTR','sgsn.%base_realm',           3600,1),
  (1254,'130.254.168.192.in-addr.arpa', 'PTR','msc.%base_realm',            3600,1),
  (1254,'150.254.168.192.in-addr.arpa', 'PTR','hnbgw.%base_realm',          3600,1),
  (1254,'170.254.168.192.in-addr.arpa', 'PTR','dra.%base_realm',            3600,1),
  (1254,'180.254.168.192.in-addr.arpa', 'PTR','sms-router.%base_realm',     3600,1),
  (1254,'*.254.168.192.in-addr.arpa',   'PTR','other.%base_realm',          3600,1);

-- EPC - %base_realm
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (10000,'%base_realm',               'SOA',  'localhost. root.localhost. 2006101001 10800 900 3600 3600',3600,1),
  (10000,'%base_realm',               'NS',   'ns.%base_realm',          3600,1),
  (10000,'ns.%base_realm',            'A',    '%dns_net_a_ipv4',         3600,1),
  (10000,'dns.%base_realm',           'A',    '%dns_net_a_ipv4',         3600,1),
  (10000,'%pdns_fqdn',                'A',    '%dns_mgmt_ipv4',          3600,1),
  (10000,'vmhost.%base_realm',        'A',    '%vmhost_mgmt_ipv4',       3600,1),
  (10000,'gw.%base_realm',            'A',    '192.168.3.1',             3600,1),
  (10000,'apn.%base_realm',           'A',    '%spgw_net_a_ipv4',        3600,1),
  (10000,'%spgw_fqdn',                'A',    '%spgw_mgmt_ipv4',         3600,1),
  (10000,'%pgw_fqdn',                 'A',    '%pgw_mgmt_ipv4',          3600,1),
  (10000,'%pgwc_fqdn',                'A',    '%pgwc_mgmt_ipv4',         3600,1),
  (10000,'%pgwu_fqdn',                'A',    '%pgwu_mgmt_ipv4',         3600,1),
  (10000,'%sgw_fqdn',                 'A',    '%sgw_mgmt_ipv4',          3600,1),
  (10000,'%sgwc_fqdn',                'A',    '%sgwc_mgmt_ipv4',         3600,1),
  (10000,'%twag_diameter_fqdn',       'A',    '%twag_mgmt_ipv4',         3600,1),
  (10000,'%epdg_diameter_fqdn',       'A',    '%epdg_mgmt_ipv4',         3600,1),
  (10000,'%angw_diameter_fqdn',       'A',    '%angw_mgmt_ipv4',         3600,1),
  (10000,'%enodeb_fqdn',              'A',    '%enodeb_mgmt_ipv4',       3600,1),
  (10000,'%enodeb2_fqdn',             'A',    '%enodeb2_mgmt_ipv4',      3600,1),
  (10000,'%nodeb_fqdn',               'A',    '%nodeb_mgmt_ipv4',        3600,1),
  (10000,'%mme_fqdn',                 'A',    '%mme_mgmt_ipv4',          3600,1),
  (10000,'%sgsn_fqdn',                'A',    '%sgsn_mgmt_ipv4',         3600,1),
  (10000,'%msc_diameter_fqdn',        'A',    '%msc_mgmt_ipv4',          3600,1),
  (10000,'%sms_router_diameter_fqdn', 'A',    '%sms_router_mgmt_ipv4',   3600,1),
  (10000,'%hss_fqdn',                 'A',    '%hss_mgmt_ipv4',          3600,1),
  (10000,'%aaa_server_fqdn',          'A',    '%aaa_server_mgmt_ipv4',   3600,1),
  (10000,'%dra_diameter_fqdn',        'A',    '%dra_mgmt_ipv4',          3600,1),
  (10000,'%www_fqdn',                 'A',    '%www_net_a_ipv4',         3600,1),
  (10000,'%www2_fqdn',                'A',    '%www_mgmt_ipv4',          3600,1),
  (10000,'%andsf_fqdn',               'A',    '%andsf_net_a_ipv4',       3600,1),
  (10000,'%andsf_diameter_fqdn',      'A',    '%andsf_mgmt_ipv4',        3600,1),
  (10000,'%pcrf_fqdn',                'A',    '%pcrf_mgmt_ipv4',         3600,1),
  (10000,'%cdf_fqdn',                 'A',    '%cdf_mgmt_ipv4',          3600,1),
  (10000,'%cgf_fqdn',                 'A',    '%cgf_mgmt_ipv4',          3600,1),
  (10000,'%bf_fqdn',                  'A',    '%bf_mgmt_ipv4',           3600,1),
  (10000,'%ocs_fqdn',                 'A',    '%ocs_mgmt_ipv4',          3600,1),
  (10000,'%http_proxy_fqdn',          'A',    '%http_proxy_net_a_ipv4',  3600,1),
  (10000,'%http_proxy_diameter_fqdn', 'A',    '%http_proxy_mgmt_ipv4',   3600,1),
  (10000,'%flowmon_fqdn',             'A',    '%www_mgmt_ipv4',          3600,1);

-- EPC APNs - %base_realm
INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
  (10000,'%default_apn',                         'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
  (10000,'%default_apn',                         'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),

  (10000,'%internet_apn',                        'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
  (10000,'%internet_apn',                        'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),

  (10000,'%ims_apn',                             'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
  (10000,'%ims_apn',                             'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),

  (10000,'%splitgw_apn',                         'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-b-srv.pgw.node.%base_realm',  3600,1),
  (10000,'%splitgw_apn',                         'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-b-srv.pgw.node.%base_realm',  3600,1),

  (10000,'%splitgwinternet_apn',                 'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-b-srv.pgw.node.%base_realm',  3600,1),
  (10000,'%splitgwinternet_apn',                 'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-b-srv.pgw.node.%base_realm',  3600,1),
-- If the destination of this is not SRV, then below you have the tiny difference as example s->a
--      (10000,'%splitgw_apn',                        'NAPTR',    10, '100 999 \"a\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-b-srv.pgw.node.%base_realm',  3600,1),

  (10000,'net-d-srv.spgw.node.%base_realm',      'SRV',      10, '0 %spgw_net_d_gtpc_port net-d.spgw.node.%base_realm',                       3600,1),
  (10000,'net-d.spgw.node.%base_realm',          'A',        10, '%spgw_net_d_ipv4',                                                          3600,1),

  (10000,'net-b-srv.pgw.node.%base_realm',       'SRV',      10, '0 %pgw_net_b_gtpc_port net-b.pgw.node.%base_realm',                         3600,1),
  (10000,'net-b.pgw.node.%base_realm',           'A',        10, '%pgw_net_b_ipv4',                                                           3600,1),

  (10000,'net-b-srv.sgw.node.%base_realm',       'SRV',      10, '0 %sgw_net_b_gtpc_port net-b.sgw.node.%base_realm',                         3600,1),
  (10000,'net-b.sgw.node.%base_realm',           'A',        10, '%sgw_net_b_ipv4',                                                           3600,1),
  (10000,'net-d-srv.sgw.node.%base_realm',       'SRV',      10, '0 %sgw_net_d_gtpc_port net-d.sgw.node.%base_realm',                         3600,1),
  (10000,'net-d.sgw.node.%base_realm',           'A',        10, '%sgw_net_d_ipv4',                                                           3600,1),
  (10000,'net-d-srv.sgsn.node.%base_realm',      'SRV',      10, '0 %sgsn_net_d_gtpc_port net-d.sgsn.node.%base_realm',                       3600,1),
  (10000,'net-d.sgsn.node.%base_realm',          'A',        10, '%sgsn_net_d_ipv4',                                                          3600,1);


-- EPC TAC - %base_realm
INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
  (10000,'tac-lb%enodeb_tac_lb.tac-hb%enodeb_tac_hb.tac.%base_realm',     'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-mme:x-s3\"      \"\"    net-d-srv.mme.node.%base_realm',  3600,1),
  (10000,'tac-lb%enodeb_tac_lb.tac-hb%enodeb_tac_hb.tac.%base_realm',     'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s11\"     \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
  (10000,'tac-lb%enodeb2_tac_lb.tac-hb%enodeb2_tac_hb.tac.%base_realm',   'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s11\"     \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
  (10000,'tac-lb%enodeb2_tac_lb.tac-hb%enodeb2_tac_hb.tac.%base_realm',   'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s11\"     \"\"    net-d-srv.sgw.node.%base_realm',  3600,1);


-- EPC RAC - %base_realm
INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
  (10000,'nri-sgsn%sgsn_nri.rac%sgsn_rac.lac%sgsn_lac.rac.%base_realm',   'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgsn:x-s3\"     \"\"    net-d-srv.sgsn.node.%base_realm', 3600,1),
  (10000,'rac%nodeb_rac.lac%nodeb_lac.rac.%base_realm',                   'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgsn:x-s3\"     \"\"    net-d-srv.sgsn.node.%base_realm', 3600,1),
  (10000,'rac%nodeb_rac.lac%nodeb_lac.rac.%base_realm',                   'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s4\"      \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
  (10000,'rac%nodeb2_rac.lac%nodeb2_lac.rac.%base_realm',                 'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s4\"      \"\"    net-d-srv.sgw.node.%base_realm',  3600,1);

-- EPC MMEs - %base_realm
INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
  (10000,'mmec%mmec_hex.mmegi%mmegi_hex.mme.%base_realm',                 'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-mme:x-s1-mme\"  \"\"    net-d-srv.mme.node.%base_realm',  3600,1),
  (10000,'net-d-srv.mme.node.%base_realm',                                'SRV',   10,    '0 %mme_net_d_gtpc_port net-d.mme.node.%base_realm',                              3600,1),
  (10000,'net-d.mme.node.%base_realm',                                    'A',     10,    '%mme_net_d_ipv4',                                                                3600,1);

-- EPC MMEs - handover
INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
  (10000,'net-d-srv.mme2.node.%base_realm',	  			  'SRV',   10,	  '0 %mme2_net_d_gtpc_port net-d.mme2.node.%base_realm',		    3600,1),
  (10000,'net-d.mme2.node.%base_realm',		  			  'A',     10,    '%mme2_net_d_ipv4',					       		            3600,1),
  (10000,'mmec%mmec2_hex.mmegi%mmegi2_hex.mme.%base_realm',		  'NAPTR', 10,	  '100 999 \"s\" \"x-3gpp-mme:x-s10-mme\"  \"\"   net-d-srv.mme2.node.%base_realm', 3600,1),
  (10000,'tac-lb%enodeb_tac_lb.tac-hb%enodeb_tac_hb.tac.%base_realm',	  'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-mme:x-s10\"      \"\"   net-d-srv.mme.node.%base_realm', 3600,1),
  (10000,'tac-lb%enodeb2_tac_lb.tac-hb%enodeb2_tac_hb.tac.%base_realm',	  'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-mme:x-s10\"      \"\"   net-d-srv.mme2.node.%base_realm', 3600,1);


-- UMTS RNCs - %base_realm
INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
  (10000,'rnc%nodeb_rnc_id_hex.rnc.%base_realm',                          'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-rnc:x-s12-rnc\"  \"\"    net-d-srv.rnc.node.%base_realm', 3600,1),
  (10000,'net-d-srv.rnc.node.%base_realm',                                'SRV',   10,    '0 %nodeb_net_d_gtpu_port net-d.rnc.node.%base_realm',                            3600,1),
  (10000,'net-d.rnc.node.%base_realm',                                    'A',     10,    '%nodeb_net_d_ipv4',                                                              3600,1);


-- EPC %visited_realm
INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (10001,'%visited_realm',         'SOA',    'localhost. root.localhost. 2006101001 10800 900 3600 3600',3600,1),
  (10001,'%visited_realm',         'NS',     'ns.%visited_realm',    3600,1),
  (10001,'ns.%visited_realm',      'A',      '%dns_net_a_ipv4',      3600,1),
  (10001,'dns.%visited_realm',     'A',      '%dns_net_a_ipv4',      3600,1),
  (10001,'vmhost.%visited_realm',  'A',      '%vmhost_mgmt_ipv4',    3600,1),
  (10001,'gw.%visited_realm',      'A',      '192.168.3.1',          3600,1),
  (10001,'%aaa_proxy_fqdn',        'A',      '%aaa_proxy_mgmt_ipv4', 3600,1);

-- IMS - %ims_realm
INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
  (20000,'%ims_realm',             'SOA',    10, 'localhost. root.localhost. 2006101001 10800 900 3600 3600',3600,1),
  (20000,'%ims_realm',             'NS',     10, 'ns.%ims_realm',                             3600,1),
  (20000,'ns.%ims_realm',          'A',      10, '%dns_net_a_ipv4',                           3600,1),
  (20000,'dns.%ims_realm',         'A',      10, '%dns_net_a_ipv4',                           3600,1),
  (20000,'vmhost.%ims_realm',      'A',      10, '%vmhost_mgmt_ipv4',                         3600,1),
  (20000,'gw.%ims_realm',          'A',      10, '192.168.3.1',                               3600,1),

  (20000,'%pcscf_diameter_fqdn',   'A',      10, '%pcscf_mgmt_ipv4',                          3600,1),
  (20000,'%icscf_diameter_fqdn',   'A',      10, '%icscf_mgmt_ipv4',                          3600,1),
  (20000,'%scscf_diameter_fqdn',   'A',      10, '%scscf_mgmt_ipv4',                          3600,1),

  (20000,'%ims_realm',             'NAPTR',  10, '10 50 \"s\" \"SIP+D2U\"  \"\"  _sip._udp',  3600,1),
  (20000,'%ims_realm',             'NAPTR',  10, '20 50 \"s\" \"SIP+D2T\"  \"\"  _sip._tcp',  3600,1),
  (20000,'_sip.%ims_realm',        'SRV',    10, '0 5061 %icscf_fqdn',                        3600,1),
  (20000,'_sip._udp.%ims_realm',   'SRV',    10, '0 5061 %icscf_fqdn',                        3600,1),
  (20000,'_sip._tcp.%ims_realm',   'SRV',    10, '0 5061 %icscf_fqdn',                        3600,1),
  (20000,'%ims_realm',             'A',      10, '%icscf_net_a_ipv4',                         3600,1),

  (20000,'%pcscf_fqdn',            'NAPTR',  10, '10 50 \"a\" \"SIP+D2U\"  \"\"  %pcscf_fqdn',3600,1),
  (20000,'%pcscf_fqdn',            'NAPTR',  10, '20 50 \"a\" \"SIP+D2T\"  \"\"  %pcscf_fqdn',3600,1),
  (20000,'_sip.%pcscf_fqdn',       'SRV',    10, '0 5060 %pcscf_fqdn',                        3600,1),
  (20000,'_sip._udp.%pcscf_fqdn',  'SRV',    10, '0 5060 %pcscf_fqdn',                        3600,1),
  (20000,'_sip._tcp.%pcscf_fqdn',  'SRV',    10, '0 5060 %pcscf_fqdn',                        3600,1),
  (20000,'%pcscf_fqdn',            'A',      10, '%pcscf_net_a_ipv4',                         3600,1),

  (20000,'%icscf_fqdn',            'NAPTR',  10, '10 50 \"a\" \"SIP+D2U\"  \"\"  %icscf_fqdn',3600,1),
  (20000,'%icscf_fqdn',            'NAPTR',  10, '20 50 \"a\" \"SIP+D2T\"  \"\"  %icscf_fqdn',3600,1),
  (20000,'_sip.%icscf_fqdn',       'SRV',    10, '0 5061 %icscf_fqdn',                        3600,1),
  (20000,'_sip._udp.%icscf_fqdn',  'SRV',    10, '0 5061 %icscf_fqdn',                        3600,1),
  (20000,'_sip._tcp.%icscf_fqdn',  'SRV',    10, '0 5061 %icscf_fqdn',                        3600,1),
  (20000,'%icscf_fqdn',            'A',      10, '%icscf_net_a_ipv4',                         3600,1),
  (20000,'%scscf_fqdn',            'NAPTR',  10, '10 50 \"a\" \"SIP+D2U\"  \"\"  %scscf_fqdn',3600,1),
  (20000,'%scscf_fqdn',            'NAPTR',  10, '20 50 \"a\" \"SIP+D2T\"  \"\"  %scscf_fqdn',3600,1),
  (20000,'_sip.%scscf_fqdn',       'SRV',    10, '0 5062 %scscf_fqdn',                        3600,1),
  (20000,'_sip._udp.%scscf_fqdn',  'SRV',    10, '0 5062 %scscf_fqdn',                        3600,1),
  (20000,'_sip._tcp.%scscf_fqdn',  'SRV',    10, '0 5062 %scscf_fqdn',                        3600,1),
  (20000,'%scscf_fqdn',            'A',      10, '%scscf_net_a_ipv4',                         3600,1),

  (20000,'%sms_router_fqdn',       'A',      10, '%sms_router_net_a_ipv4',                    3600,1),
  (20000,'%smsc_fqdn',             'A',      10, '%smsc_net_a_ipv4',                          3600,1),
  (20000,'%mdf_fqdn',              'A',      10, '%mdf_net_a_ipv4',                           3600,1),
  (20000,'%mdf_diameter_fqdn',     'A',      10, '%mdf_mgmt_ipv4',                            3600,1),
  (20000,'www.%ims_realm',         'A',      10, '%www_mgmt_ipv4',                            3600,1),
  (20000,'www2.%ims_realm',        'A',      10, '%www_net_a_ipv4',                           3600,1),

  (20000,'%enum_tel_volte1.%ims_realm','NAPTR', 10, '10 100 \"u\" \"E2U+sip\" \"!^.*$!sip:%imsi_volte1@%ims_realm!\".',  3600,1),
  (20000,'%enum_tel_volte2.%ims_realm','NAPTR', 10, '10 100 \"u\" \"E2U+sip\" \"!^.*$!sip:%imsi_volte2@%ims_realm!\".',  3600,1),

  (20000,'%enum_tel_vocs1.%ims_realm', 'NAPTR', 10, '10 100 \"u\" \"E2U+sip\" \"!^.*$!sip:%imsi_vocs1@%ims_realm!\".',    3600,1),
  (20000,'%enum_tel_vocs2.%ims_realm', 'NAPTR', 10, '10 100 \"u\" \"E2U+sip\" \"!^.*$!sip:%imsi_vocs2@%ims_realm!\".',    3600,1);

INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
  (30000,'openepc.test',           'SOA',  'localhost. root.localhost. 2006101001 10800 900 3600 3600',3600,1),
  (30000,'openepc.test',           'NS',   'ns.%ims_realm',          3600,1),
  (30000,'www.openepc.test',       'A',    '%www_mgmt_ipv4',         3600,1),
  (30000,'www2.openepc.test',      'A',    '%www_net_a_ipv4',        3600,1);


/*!40000 ALTER TABLE `records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `supermasters`
--

LOCK TABLES `supermasters` WRITE;
/*!40000 ALTER TABLE `supermasters` DISABLE KEYS */;
/*!40000 ALTER TABLE `supermasters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tsigkeys`
--

LOCK TABLES `tsigkeys` WRITE;
/*!40000 ALTER TABLE `tsigkeys` DISABLE KEYS */;
/*!40000 ALTER TABLE `tsigkeys` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
