#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_interface "enodeb_mgmt"
load_interface "enodeb_net_c"
load_interface "enodeb_net_d"

set_data_topology "enodeb_mgmt_ipv4" $enodeb_mgmt
set_data_topology "enodeb_net_c_ipv4" $enodeb_net_c
set_data_topology "enodeb_net_d_ipv4" $enodeb_net_d
