#!/bin/bash
#
# Script to install an entire system
#

# Chicken and the egg problem. Basic_config.sh should be loaded in profile or something at best.
if [ -z "$OpenEPC_path" ] ; then
  source "/opt/OpenEPC/basic_config.sh"
fi

# Utils
source "$OpenEPC_file_utils"
source "$OpenEPC_path_install/install_utils.sh"

# Installation configuration
source "$OpenEPC_path_data/data_installation.sh"
source "$OpenEPC_path_data/data_topology.sh"


# echoes the usage of this script
function usage
{
    echo 'usage: install_system [PARAMETERS...]

        -?, -h, --help, --usage         display this help message

    Parameters that temporary changes the behavior:
	-o, --offline			disable installation of dependencies which require internet access
        -nc, --no-compilation           disable Wharf and Kamailio compilations
        -nd, --no-databases             disable creation of new databases (useful for re-runs to keep provisioned data)
        -ndns, --no-dns                 disable re-generation of PowerDNS DB (useful for re-runs to keep the provisioned DNS data)
        -rm, -d, --remove-history       only delete the history, nothing else
        -s, --service                   OpenEPC service to be installed

    Set variables for automation
        -t, --type                      setup type; can be <virtual> or <physical>
        -mdf, --mdf-stream              Media Delivey Function installation : <none>, <fileplay>, <webcam>
        -c, --client                    client to be installed : <Alice>, <Bob>, <Charlie>, <Dave>, <Emma>
        -a, --client-auth               authentication scheme for the client : <aka>, <aka_prime>
        -m, --multi-access              Mobility Manager with multi access (MAPCON/IFOM) : <yes>, <no>
        -i, --ipsec                     install ipsec on the client: <yes>, <no>
        -e, --enodeb-type               can be a single eNodeB or emulate multiple ones:<standalone> or <multiple>

        missing parameters will be asked for interactively'
}

#User input variables
OpenEPC_node=
OpenEPC_SGW_MME_SGSN_setup_type=
OpenEPC_MDF_stream=
OpenEPC_EPC_Enablers_setup_type=
rm_only=false


# set variables with content from script parameters
while [ "$1" != "" ]; do
    case $1 in
            # export because install_clean_db.sh is called as external script and won't see local vars
	 -o | --offline)
            export OpenEPC_offline=true
          ;;
        -nc | --no-compilation)
            OpenEPC_no_compilation=true
          ;;
        -nd | --no-databases)
            # export because install_clean_db.sh is called as external script and won't see local vars
            export OpenEPC_no_databases=true
          ;;
        -ndns | --no-dns)
            OpenEPC_no_dns=true
          ;;
        -rm | -d | --remove-history)
            rm_only=true
            ;;
        -s | --service)   shift
            OpenEPC_node=$1
            install_config_add_var OpenEPC_node
          ;;
        -t | --type)      shift
            OpenEPC_SGW_MME_SGSN_setup_type=$1
            OpenEPC_EPC_Enablers_setup_type=$1
            OpenEPC_Client_setup_type=$1
            OpenEPC_TWAG_setup_type=$1
          ;;
        -mdf | --mdf-stream)   shift
            OpenEPC_MDF_stream=$1
          ;;
        -c | --client)    shift
            OpenEPC_Client_id=$1
          ;;
        -a | --client-auth)   shift
            OpenEPC_Client_EAP_algorithm=$1
          ;;
        -m | --multi-access)  shift
            OpenEPC_Client_mm_multi_access=$1
          ;;
        -i | --ipsec)    shift
            OpenEPC_ePDG_IPsec_enabled=$1
            OpenEPC_Client_IPsec_enabled=$1
          ;;
        -e | --enodeb-type)  shift
            OpenEPC_ENODEB_mode=$1
          ;;
        -? | -h | --help | --usage)
            usage
            exit
            ;;
        * )
            usage
            exit 1
    esac
    shift
done

tput setaf 5 ; tput bold ;tput setaf 4 ; tput setab 7
echo -e "\n----------------------------------- OpenEPC Installation Script -------------------------------------------"
tput sgr 0
echo -e "\n\n"

if [ "$rm_only" = true ]; then
  rm $OpenEPC_path_install/install_config.sh && openepc_log_err "Removed local installation history. Please re-run the script to install new components. \n "
  exit 0
fi

if [ -e  $OpenEPC_path_install/install_config.sh ]; then
  source  $OpenEPC_path_install/install_config.sh
fi

# Basic packages needed for this
if [ "$OpenEPC_offline" = "true" ] ; then
  openepc_log "Offline mode.Skip installaing basic packages..."
else
  try_skip prereq_install
fi

if [ -z "$OpenEPC_node"  ]; then
  openepc_log "Supporting now:"
  openepc_log "  allinone"
  openepc_log "  epc-enablers hss-cscfs"
  openepc_log "  pgw spgw spgw-dpdk sgw twag epdg angw sgw-mme sgw-mme-sgsn"
  openepc_log "  mme mme2 sgsn mme-sgsn mme-sgsn-msc-hnbgw"
  openepc_log "  nodeb enodeb enodeb2 enodeb-radio"
  openepc_log "  epc-client ims-client"
  echo -en "\nWhich node are you configuring?: "
  install_config_read_var OpenEPC_node
else
  openepc_log_warn
  openepc_log_warn "Preconfigured as [$OpenEPC_node] - will re-install"
  openepc_log_warn
fi


# Check interfaces
check_for_present_interfaces $OpenEPC_node

case "$OpenEPC_node" in

  "pgw")
      name="pgw"
      openepc_log "Re-linking pdn_ops DB to use the data for the $splitgw_apn APN (standalone PGW)"
      try_fail rm -f $OpenEPC_path_install/data_provisioning_pdn_ops.sh
      try_fail ln -sf $OpenEPC_path_install/data_provisioning_pdn_ops_pgw.sh $OpenEPC_path_install/data_provisioning_pdn_ops.sh
      config_system $name
      build_wharf
      service_enable_and_start_all pgw
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.pgw
    ;;

  "sgw")
      name="sgw"
      build_wharf
      config_system $name
      service_enable_and_start_all sgw
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.sgw
    ;;

  "angw")
      name="angw"
      build_wharf
      config_system $name
      service_enable_and_start_all angw
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.angw
    ;;

  "spgw")
      #SPGW - Currently supported only for LTE Access
      #NOTE:While running SPGW, always make sure that MME only in configured on SGW-MME-SGSN Machine
      name="spgw"
      openepc_log "Re-linking pdn_ops DB to use the data for the default APNs (combined S/PGW)"
      try_fail rm -f $OpenEPC_path_install/data_provisioning_pdn_ops.sh
      try_fail ln -sf $OpenEPC_path_install/data_provisioning_pdn_ops_spgw.sh $OpenEPC_path_install/data_provisioning_pdn_ops.sh
      config_system $name
      build_wharf
      service_enable_and_start_all spgw
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.spgw
    ;;

  "spgw-dpdk")
      #SPGW-DPDK - Currently supported only for LTE Access
      #NOTE:While running SPGW-DPDK, always make sure that MME only in configured on SGW-MME-SGSN Machine
      name="spgw-dpdk"

      openepc_log "The SPGW-DPDK has very high CPU usage. Therefore, it is not recommended to enable it at startup."
      openepc_log_question "Should the service be enabled at stratup anyway? (yes, no) [no]"
      read $var_name
      eval var_value=\$$var_name
      if [ -z "$var_value" ] ; then
        OpenEPC_spgw_dpdk_enable_boot="n"
      elif [[ "$var_value" =~ ^([yY][eE][sS]|[yY])$ ]] ; then
        OpenEPC_spgw_dpdk_enable_boot="y"
      else
        OpenEPC_spgw_dpdk_enable_boot="n"
      fi
      install_config_write_vars OpenEPC_spgw_dpdk_enable_boot $OpenEPC_spgw_dpdk_enable_boot

      openepc_log "Re-linking pdn_ops DB to use the data for the default APNs (combined S/PGW-DPDK)"
      try_fail rm -f $OpenEPC_path_install/data_provisioning_pdn_ops.sh
      try_fail ln -sf $OpenEPC_path_install/data_provisioning_pdn_ops_spgw.sh $OpenEPC_path_install/data_provisioning_pdn_ops.sh
      config_system $name
      config_system_dpdk $name
      build_wharf_dpdk
      build_wharf

      service_configure_init spgw-dpdk
      if [ "$OpenEPC_spgw_dpdk_enable_boot" = "y" ] ; then
        service_enable_boot_start spgw-dpdk
      fi

      # TODO: check if hugepages and drivers are set up. if yes, allow to start now.
      openepc_log_question "A reboot is required. Do you want to reboot now? (yes, no) [y]"
      read $var_name
      eval var_value=\$$var_name
      if [[ "$var_value" =~ ^([nN][oO]|[nN])$ ]] ; then
        reboot_now="n"
      else
        reboot_now="y"
      fi

      if [ "$reboot_now" = "y" ] ; then
        sudo reboot
      fi
    ;;

  "pgwc")
      name="pgwc"
      config_system $name
      build_wharf
      service_enable_and_start_all pgwc
    ;;

  "pgwu")
      name="pgwu"
      config_system $name
      build_wharf
      service_enable_and_start_all pgwu
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.pgwu
    ;;

  "mme")
      name="mme"
      build_wharf
      config_system $name
      service_enable_and_start_all $name
    ;;

  "mme2")
      name="mme2"
      build_wharf
      config_system $name
      service_enable_and_start_all $name
    ;;

  "sgsn")
      if [ -z "$OpenEPC_SGSN_setup_type"  ]; then
        echo -n "Configuring the sgsn for which kind of external setup? (virtual, physical) [virtual]:"
        install_config_read_var OpenEPC_SGSN_setup_type "virtual"
      fi
      name="sgsn"
      build_wharf
      config_system $name

      if  [ "$OpenEPC_SGSN_setup_type" = "physical" ] ; then
        #make_link "$OpenEPC_path_etc/sgsn_physical.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="sgsn msc hnbgw"
      elif [ "$OpenEPC_SGSN_setup_type" = "virtual" ] ; then
        #make_link "$OpenEPC_path_etc/sgsn_virtual.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="sgsn"
      else
        openepc_log_err -e "Selected option [$OpenEPC_SGSN_setup_type] not recognized, using virtualized setup\n "
      fi
      service_enable_and_start_all $services
    ;;

  "mme-sgsn")
      if [ -z "$OpenEPC_MME_SGSN_setup_type"  ]; then
        echo -n "Configuring the mme-sgsn for which kind of setup? (virtual, physical) [virtual]:"
        install_config_read_var OpenEPC_MME_SGSN_setup_type "virtual"
      fi
      name="mme-sgsn"
      build_wharf
      config_system $name

      if  [ "$OpenEPC_MME_SGSN_setup_type" = "physical" ] ; then
        #make_link "$OpenEPC_path_etc/sgsn_physical.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="mme sgsn msc hnbgw"
      elif [ "$OpenEPC_MME_SGSN_setup_type" = "virtual" ] ; then
        #make_link "$OpenEPC_path_etc/sgsn_virtual.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="mme sgsn"
      else
        openepc_log_err -e "selected option not recognized, using virtualized setup \n "
      fi
      service_enable_and_start_all $services
    ;;

  "mme-sgsn-msc-hnbgw")
      name="mme-sgsn-msc-hnbgw"
      build_wharf
      config_system $name
      services="mme sgsn msc hnbgw"
      service_enable_and_start_all $services
    ;;

  "sgw-mme")
      name="sgw-mme"
      build_wharf
      config_system $name
      services="sgw mme"
      service_enable_and_start_all $services
    ;;

  "sgw-mme-sgsn")
      if [ -z "$OpenEPC_SGW_MME_SGSN_setup_type"  ]; then
        echo -n "Configuring the sgw-mme-sgsn for which kind of setup? (virtual, physical) [virtual]:"
        install_config_read_var OpenEPC_SGW_MME_SGSN_setup_type "virtual"
      fi
      name="sgw-mme-sgsn"
      build_wharf
      config_system $name

      if  [ "$OpenEPC_SGW_MME_SGSN_setup_type" = "physical" ] ; then
        #make_link "$OpenEPC_path_etc/sgsn_physical.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="sgw mme sgsn msc hnbgw"
      elif [ "$OpenEPC_SGW_MME_SGSN_setup_type" = "virtual" ] ; then
        #make_link "$OpenEPC_path_etc/sgsn_virtual.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="sgw mme sgsn"
      else
        openepc_log_err -e "selected option not recognized, using virtualized setup \n "
      fi
      service_enable_and_start_all $services
    ;;


  "sgwc-mme-sgsn")
      echo -n "Configuring the sgwc-mme-sgsn for which kind of setup? (virtual, physical) [virtual]:"
      install_config_read_var OpenEPC_SGWC_MME_SGSN_setup_type "virtual"

      name="sgwc-mme-sgsn"
      build_wharf
      config_system $name

      if  [ "$OpenEPC_SGWC_MME_SGSN_setup_type" = "physical" ] ; then
        make_link "$OpenEPC_path_etc/sgsn_physical.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="sgwc mme sgsn msc hnbgw"
      elif [ "$OpenEPC_SGWC_MME_SGSN_setup_type" = "virtual" ] ; then
        make_link "$OpenEPC_path_etc/sgsn_virtual.xml" "$OpenEPC_path_etc/sgsn.xml"
        services="sgwc mme sgsn"
      else
        openepc_log_err -e "selected option not recognized, using virtualized setup \n "
      fi
      service_enable_and_start_all $services
    ;;


  "sgwu")
      name="sgwu"
      build_wharf
      config_system $name
      service_enable_and_start_all sgwu
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.sgwu
    ;;


  "ue")
      name="ue"
      build_wharf
      config_system $name
      service_enable_and_start_all ue
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.ue
    ;;


  "enodeb")
      echo -n "Configuring the eNodeB to run as? (standalone, multiple)[standalone]:"
      install_config_read_var OpenEPC_ENODEB_mode "standalone"

      name="enodeb"
      build_wharf
      config_system $name
      if [ "$OpenEPC_ENODEB_mode" = "multiple" ] ; then
        make_link "$OpenEPC_path_etc/enode_m.xml" "$OpenEPC_path_etc/enodeb.xml"
      elif [ "$OpenEPC_ENODEB_mode" = "standalone" ] ; then
        make_link "$OpenEPC_path_etc/enodeb_l3.xml" "$OpenEPC_path_etc/enodeb.xml"
      else
        openepc_log_err -e "selected option not recognized, using eNodeB without multi enodeb setup \n "
      fi

      service_enable_and_start_all enodeb
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.enodeb
    ;;

  "enodeb2")
      echo -n "Configuring the eNodeB 2 to run as? (standalone, multiple)[standalone]:"
      install_config_read_var OpenEPC_ENODEB_mode "standalone"

      name="enodeb2"
      build_wharf
      config_system $name
      if [ "$OpenEPC_ENODEB_mode" = "multiple" ] ; then
        make_link "$OpenEPC_path_etc/enode_m2.xml" "$OpenEPC_path_etc/enodeb2.xml"
      elif [ "$OpenEPC_ENODEB_mode" = "standalone" ] ; then
        make_link "$OpenEPC_path_etc/enodeb_l32.xml" "$OpenEPC_path_etc/enodeb2.xml"
      else
        openepc_log_err -e "selected option not recognized, using eNodeB2 without multi enodeb setup \n "
      fi

      service_enable_and_start_all enodeb2
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.enodeb2
    ;;


  "enodeb-radio")
      name="enodeb-radio"
      build_wharf
      config_system $name
      make_link "$OpenEPC_path_etc/enodeb_radio.xml" "$OpenEPC_path_etc/enodeb.xml"
      service_enable_and_start_all enodeb
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.enodeb
    ;;


  "nodeb")
      name="nodeb"
      build_wharf
      config_system $name
      service_enable_and_start_all nodeb
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.nodeb
    ;;


  "epdg")
      echo -n "Include support for untrusted non-3gpp access, eg. IPsec tunnel support? (yes, no) [no]:  "
      install_config_read_var OpenEPC_ePDG_IPsec_enabled "no"

      if [ "$OpenEPC_ePDG_IPsec_enabled" = "yes" ] ; then
        echo "Installing GNU Multi Precision library gmp"
        install_package libgmp-dev
        openepc_log "Installing StrongSwan v5.1.2"
        cd /opt/OpenEPC/etc/
        if [ ! -f strongswan-5.1.2.tar.bz2 ] ; then
          wget http://download.strongswan.org/strongswan-5.1.2.tar.bz2
        fi
        rm -rf strongswan-5.1.2
        tar xjvf strongswan-5.1.2.tar.bz2
        cd strongswan-5.1.2
        make clean && make distclean
        ./configure --prefix=/usr --sysconfdir=/etc --enable-eap-radius --enable-eap-identity -enable-dhcp --with-random-device=/dev/urandom
        make && make install
        rm /etc/ipsec.conf
        ln -s /opt/OpenEPC/etc/strongswan/epdg/ipsec.conf /etc/ipsec.conf
        rm /etc/ipsec.secrets
        ln -s /opt/OpenEPC/etc/strongswan/epdg/ipsec.secrets /etc/ipsec.secrets
        rm /etc/strongswan.conf
        ln -s /opt/OpenEPC/etc/strongswan/epdg/strongswan.conf /etc/strongswan.conf
        rm /etc/strongswan.d/charon.conf
        ln -s /opt/OpenEPC/etc/strongswan/epdg/strongswan.d/charon.conf /etc/strongswan.d/charon.conf

        #Certficates
        cd /opt/OpenEPC/etc/certificate_authority
        echo "Generating certificates..."
        echo  "Generating caKey.der..."
        ipsec pki --gen > caKey.der
        echo  "Generating caCert.der..."
        ipsec pki --self --in caKey.der --dn "C=CH, O=CND, CN=CND CA" --ca --san epdg.epc.mnc001.mcc001.pub.3gppnetwork.org > caCert.der
        echo "Generating peerKey.der..."
        ipsec pki --gen > peerKey.der
        echo "Generating peerCert.der..."
        ipsec pki --pub --in peerKey.der | ipsec pki --issue --cacert caCert.der --cakey caKey.der \
        --dn "C=CH, O=CND, CN=peer" --san epdg.epc.mnc001.mcc001.pub.3gppnetwork.org > peerCert.der

        openepc_log_err "Getting the certificates on the client machine. This operation will succeed *ONLY* if the OpenEPC installation script
          ( $OpenEPC_path/install/install_system.sh ) has already been executed on the client machine and the folder
          '/etc/ipsec.d' already exists there, otherwise the certificates and key ( peerCert.der, peerKey.der, caCert.der )
          will have to be copied manually !!"
        install_package sshfs
        if [ ! -d /opt/ipsec.d/ ]; then
          mkdir /opt/ipsec.d/
        else
          umount /opt/ipsec.d
        fi
        sshfs 192.168.254.100:/etc/ipsec.d/ /opt/ipsec.d/
        if [ ! -d /opt/ipsec.d/certs ] ; then
          openepc_log_err "Error mounting client /etc/ipsec.d/, please copy peerCert.der and peerKey.der and caCert.der manually."
        else
          cp peerKey.der /opt/ipsec.d/private
          cp peerCert.der /opt/ipsec.d/certs/
          cp caCert.der /opt/ipsec.d/cacerts/
          openepc_log_warn "Successfully copied the certificates and the key on the client machine !"
          umount /opt/ipsec.d/
          if [ -d /opt/ipsec.d/ ]; then
            openepc_log_err "Could not unmount client /etc/ipsec.d/ please unmount manually."
          fi
          openepc_log_warn "Replacing local configs..."
          rm -f /etc/ipsec.d/cacerts/caCert.der && rm -f /etc/ipsec.d/private/caKey.der
          ln -s /opt/OpenEPC/etc/certificate_authority/caCert.der /etc/ipsec.d/cacerts/caCert.der
          ln -s /opt/OpenEPC/etc/certificate_authority/caKey.der /etc/ipsec.d/private/caKey.der
          #services="$services ipsec"
          #set_sysv_rc "ipsec_radius" on
        fi
        if [ -e "/opt/OpenEPC/etc/epdg.xml" ]; then
          rm -rf /opt/OpenEPC/etc/epdg.xml
        fi
        make_link "$OpenEPC_path_etc/epdg_gtpv2_ipsec.xml" "$OpenEPC_path_etc/epdg.xml"
      else
        make_link "$OpenEPC_path_etc/epdg_pmip.xml" "$OpenEPC_path_etc/epdg.xml"
      fi

      name="epdg"
      build_wharf
      config_system $name
      services="epdg"
      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.epdg
      service_enable_and_start_all $services
    ;;


  "twag")
      echo -e "\nThe TWAG can be configured to work with a built-in hostapd (as in the virtual setup) or with a stand-alone separate AN authenticator (e.g. WiFi or WiMAX AP supporting RADIUS-EAP authentication)"
      echo -n "Configuring the TWAG for which kind of setup? (virtual, physical) [virtual]:"
      install_config_read_var OpenEPC_TWAG_setup_type "virtual"

      name="twag"
      build_wharf
      config_system $name

      #HostAPd
      if [ "$OpenEPC_TWAG_setup_type" = "virtual" ] ; then
        openepc_log "Configuring HostAPd"
        cd "$OpenEPC_path_etc/hostapd"
        try_fail ./prereq.sh
        #cd "$OpenEPC_path_etc"
        #make_etc_link "init/hostapd_vmteam" "init.d/hostapd_vmteam"
        #set_sysv_rc "hostapd_vmteam" on
      fi

      if [ "$OpenEPC_TWAG_setup_type" = "virtual" ] ; then
        service_enable_and_start_all twag hostapd_vmteam aaa_server_proxy
      else
        service_enable_and_start_all twag aaa_server_proxy
      fi

      # Run the script in order to disable the generic-receive-offload for the network card right away, not only at reboot
      cd "$OpenEPC_path_etc"
      ./rc.local.twag
    ;;


  "epc-enablers")
      name="epc-enablers"
      # Building Wharf
      build_wharf
      config_system $name no_resolv_conf

        # new config
  #      try_fail sed -i 's/192.168.3.0\/24 via 192.168.1.1[0-1]/192.168.3.0\/24 via 192.168.1.210/'            "$OpenEPC_path_data/data_topology.sh"
  #      try_fail sed -i 's/fc00:1234:3::\/48 via fc00:1234:1::1[0-1]/fc00:1234:3::\/48 via fc00:1234:1::210/'  "$OpenEPC_path_data/data_topology.sh"
        # old config
  #      try_fail sed -i 's/192.168.3.0\/24 via 192.168.1.1[0-1]/192.168.3.0\/24 via 192.168.1.210/'            "$OpenEPC_path_etc/network/set_ip.sh"
  #      try_fail sed -i 's/fc00:1234:3::\/48 via fc00:1234:1::1[0-1]/fc00:1234:3::\/48 via fc00:1234:1::210/'  "$OpenEPC_path_etc/network/set_ip.sh"
  #    fi

      # Building Web GUI
      if [ "$OpenEPC_offline" = "true" ] ; then
      	  openepc_log "Offline mode.Skip web GUI dependencies installation..."
    	else
	  try_fail prereq_www
      fi
      openepc_log "Configuring Web Provisioning GUI for specific topology"
      cp -rf $OpenEPC_path_wharf/gui/www/* /var/www/html
      # Replace GUI configs and menu with setup-specific ones
      cd /var/www/html
      try_fail rm -rf lma-spgw lma-pgw pcef-spgw pcef-pgw mag-sgw mag-twag mag-epdg mag-angw bberf-sgw bberf-twag bberf-epdg enodeb2
      try_fail cp -rf lma lma-spgw
      try_fail cp -rf lma lma-pgw
      try_fail rm -rf lma
      try_fail cp -rf mag mag-sgw
      try_fail cp -rf mag mag-twag
      try_fail cp -rf mag mag-epdg
      try_fail cp -rf mag mag-angw
      try_fail rm -rf mag
      try_fail cp -rf pcef pcef-pgw
      try_fail cp -rf pcef pcef-spgw
      try_fail rm -rf pcef
      try_fail cp -rf bberf bberf-sgw
      try_fail cp -rf bberf bberf-twag
      try_fail cp -rf bberf bberf-epdg
      try_fail rm -rf bberf
      try_fail cp -rf enodeb enodeb2
      # $OpenEPC_path_etc/www holds preconfigured "config.inc" files. Those will be the ones actually used by the web gui.
      cp -rf "$OpenEPC_path_etc/www/"* /var/www/html/
      cp "$OpenEPC_path_etc/www/.htpasswd" /var/www/html/

      # Install pcscd for SIM card provisioning from GUI
      if [ "$OpenEPC_offline" = "true" ] ; then
        openepc_log "Offline mode.Skipping usim dependencies installation..."
      else
        try_skip prereq_usim
      fi

      # Download and install Kamailio (new OpenIMS)
      if [ "$OpenEPC_offline" = "true" ] ; then
        openepc_log "Offline mode.Skip Kamailio dependencies installation..."
      else
        cd "$OpenEPC_path_install"
        openepc_log "Installing Kamailio dependencies..."
        try_skip prereq_kamailio
      fi

      build_kamailio
      cd $OpenEPC_path_etc
      try_fail $OpenEPC_path_etc/cscf_expand_templates.sh

      # In order to set the MTU
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.epc-enablers

      #Grant rights for managing the system via web interface
      if [ "$(grep -l www-data.*systemctl /etc/sudoers)" != "/etc/sudoers" ] ; then
        echo "" >> /etc/sudoers
        echo "www-data ALL=NOPASSWD: /bin/systemctl" >> /etc/sudoers;
        echo "www-data ALL=NOPASSWD: /sbin/start" >> /etc/sudoers;
        echo "www-data ALL=NOPASSWD: /sbin/stop" >> /etc/sudoers;
        echo "www-data ALL=NOPASSWD: /sbin/restart" >> /etc/sudoers;
      fi

      if [ "$OpenEPC_no_dns" = "true" ] ; then
        openepc_log "Skip DNS (Re)Configuration and (Re)Provisioning"
      else
	if [ "$OpenEPC_offline" = "true" ] ; then
      	  openepc_log "Offline mode.Skip PDNS installation..."
    	else
          install_pdns
	fi
      fi

      # Make DNS stick even if using DHCP on the Internet breakout interface
      if [ -d "/etc/dhcp/dhclient-exit-hooks.d" ] ; then
        make_etc_link "dhcp/dhclient-exit-hooks.d/reset_dns" "dhcp/dhclient-exit-hooks.d/reset_dns"
      fi

  #    if [ "$OpenEPC_OFP" = "yes" ] ; then
      make_resolv_conf

      services="pcrf andsf pcscf icscf scscf hss cdf cgf bf ocs aaa_server sms_router"
      service_enable_and_start_all $services
    ;;


  "hss-cscfs")
      name="hss-cscfs"
      # Building Wharf
      build_wharf
      config_system $name no_resolv_conf

      if [ "$OpenEPC_no_dns" = "true" ] ; then
        openepc_log "Skip DNS (Re)Configuration and (Re)Provisioning"
      else
        install_pdns
      fi

      # Make DNS stick even if using DHCP on the Internet breakout interface
      if [ -d "/etc/dhcp/dhclient-exit-hooks.d" ] ; then
        make_etc_link "dhcp/dhclient-exit-hooks.d/reset_dns" "dhcp/dhclient-exit-hooks.d/reset_dns"
      fi

      # Building Web GUI
      try_fail prereq_www
      openepc_log "Configuring Web Provisioning GUI for specific topology"
      cp -rf $OpenEPC_path_wharf/gui/www/* /var/www/html
      # Replace GUI configs and menu with setup-specific ones
      cd /var/www/html
      # nothing here
      # $OpenEPC_path_etc/www holds preconfigured "config.inc" files. Those will be the ones actually used by the web gui.
      cp -rf "$OpenEPC_path_etc/www/"* /var/www/html/
      cp "$OpenEPC_path_etc/www/.htpasswd" /var/www/html/

      # Install pcscd for SIM card provisioning from GUI
      try_skip prereq_usim

      # Download and install Kamailio (new OpenIMS)
      cd "$OpenEPC_path_install"
      openepc_log "Installing Kamailio"
      try_skip prereq_kamailio
      build_kamailio
      cd $OpenEPC_path_etc
      try_fail $OpenEPC_path_etc/cscf_expand_templates.sh

      #Compile RTPP
      #cd $OpenEPC_path_etc/rtpproxy
      #./prereq.sh

      services="pcscf pcscf.pcc icscf scscf hss"

      service_enable_and_start_all $services
    ;;


  "epc-client")
      echo -n "Which EPC/IMS UE do you want to configure? (alice, bob) [alice]:"
      install_config_read_var OpenEPC_Client_id "alice"

      echo -n "Use Mobility Manager with multi access?(yes,no) [no]: "
      install_config_read_var OpenEPC_Client_mm_multi_access "no"

      if [ "$OpenEPC_Client_mm_multi_access" = "no" ]; then

        echo -e "\nThe client can be configured on a physical system, using physical wireless interfaces, or on a virtual machine with simulated interfaces."
        echo -n "Configuring the client for which kind of setup? (virtual, physical) [virtual]:"
        install_config_read_var OpenEPC_Client_setup_type "virtual"

        echo -e "\nFor authentication in trusted non-3GPP networks, the client can opt between using EAP-AKA or EAP-AKA' authentication."
        echo -n "Which EAP algorithm to use? (aka, aka_prime) [aka]:"
        install_config_read_var OpenEPC_Client_EAP_algorithm "aka"

        echo -e "\tThe client can be configured to enable IPsec tunneling, or without"
        echo "Include support for untrusted non-3gpp access, eg. IPsec tunnel support?"
        echo -n "Answering yes will install a patched version of Strong Swan v5.1.2 (yes, no) [no]:"
        install_config_read_var OpenEPC_Client_IPsec_enabled "no"

        if [ "$OpenEPC_Client_IPsec_enabled" = "yes" ] ; then

          cp $OpenEPC_path_etc/network/interfaces.ipsec.epc-client-alice $OpenEPC_path_etc/network/interfaces.epc-client-alice
          echo "Installin GNU Multi Precision library gmp"
          install_package libgmp-dev
          echo "Installing Strong Swan"
          mv /opt/OpenEPC/strongswan-5.1.2 /opt/OpenEPC/etc
          cd /opt/OpenEPC/etc/strongswan-5.1.2
          ./prereq.sh
          rm /etc/ipsec.conf
          ln -s /opt/OpenEPC/etc/strongswan/client/ipsec.conf /etc/ipsec.conf
          rm /etc/ipsec.secrets
          ln -s /opt/OpenEPC/etc/strongswan/client/ipsec.secrets /etc/ipsec.secrets
          rm /etc/strongswan.conf
          ln -s /opt/OpenEPC/etc/strongswan/client/strongswan.conf /etc/strongswan.conf
          rm /etc/strongswan.d/charon.conf
          ln -s /opt/OpenEPC/etc/strongswan/client/strongswan.d/charon.conf /etc/strongswan.d/charon.conf

          # Enable SSH Root Login
          sed -i 's/PermitRootLogin without-password/PermitRootLogin yes/g' /etc/ssh/sshd_config
          service ssh restart
        fi
        # Mobility Manager Network Configuration
        if [ "$OpenEPC_Client_setup_type" = "virtual" ] ; then
          make_link "$OpenEPC_path_etc/mm_vmteam_$OpenEPC_Client_id.xml" "$OpenEPC_path_etc/mm.xml"
          if [ "$OpenEPC_Client_IPsec_enabled" = "yes" ] ; then
            make_link "$OpenEPC_path_etc/mm_network_vmteam_ipsec.xml" "$OpenEPC_path_etc/mm_network.xml"
          else
            make_link "$OpenEPC_path_etc/mm_network_vmteam.xml" "$OpenEPC_path_etc/mm_network.xml"
          fi
        else
          make_link "$OpenEPC_path_etc/mm_$OpenEPC_Client_id.xml" "$OpenEPC_path_etc/mm.xml"
          make_link "$OpenEPC_path_etc/mm_network_real.xml" "$OpenEPC_path_etc/mm_network.xml"
        fi

        # Configure authentication algorithm
        try_fail sed -i 's/eap_aka\(_prime\)\?/eap_$OpenEPC_Client_EAP_algorithm/' "$OpenEPC_path_etc/mm.xml"

      else
        ln -sf "/opt/OpenEPC/etc/mm_multi_access_$OpenEPC_Client_id.xml" /opt/OpenEPC/etc/mm.xml
        ln -sf "/opt/OpenEPC/etc/mm_multi_access_network.xml" /opt/OpenEPC/etc/mm_network.xml
      fi
      name="epc-client-$OpenEPC_Client_id"
      config_system $name no_resolv_conf
      build_wharf

      # Disable NetworkManager
      try_skip disable_network_manager

      # wpa_supplicant with SoftSIM
      try_skip prereq_wpa_supplicant

      #Mobility Manager GUI
      try_skip prereq_mm_gui

      # Monster
      try_skip prereq_monster

      # Disable default route management for the Point to Point Protocol
      echo nodefaultroute >> /etc/ppp/peers/wvdial

      service_enable_and_start_all mm
      ;;

  "ims-client")
      echo -n "Which IMS UE do you want to configure? (alice, bob) [alice]:"
      install_config_read_var OpenEPC_IMS_Client_Id "alice"
      name="ims-client-$OpenEPC_IMS_Client_Id"
      config_system $name
      #build_wharf

      # Monster
      openepc_log "Configuring myMONSTER (IMS and SIP client)"
      cd "$OpenEPC_path/monster"
      ./prereq.sh
      make_link "$OpenEPC_path_etc/monster.$OpenEPC_IMS_Client_Id" "$OpenEPC_path_etc/monster"
      make_link "$OpenEPC_path_bin/monster_Alice.desktop" "/root/Desktop/MONSTER.Alice.desktop"
      make_link "$OpenEPC_path_bin/monster_Bob.desktop" "/root/Desktop/MONSTER.Bob.desktop"

      ifdown net_a
      ifup net_a
      ifdown mgmt
      ifup mgmt
      ;;


  "allinone")
      name="allinone"
      build_wharf

      openepc_log "Re-linking pdn_ops DB to use the data for the default APNs (combined S/PGW)"
      try_fail rm -f $OpenEPC_path_install/data_provisioning_pdn_ops.sh
      try_fail ln -sf $OpenEPC_path_install/data_provisioning_pdn_ops_spgw.sh $OpenEPC_path_install/data_provisioning_pdn_ops.sh

      config_system $name no_resolv_conf

      if [ "$OpenEPC_no_dns" = "true" ] ; then
        openepc_log "Skip DNS (Re)Configuration and (Re)Provisioning"
      else
        if [ "$OpenEPC_offline" = "true" ] ; then
          openepc_log "Offline mode.Skip PDNS installation..."
        else
          install_pdns
        fi
      fi

      make_resolv_conf

      # Make DNS stick even if using DHCP on the Internet breakout interface
      if [ -d "/etc/dhcp/dhclient-exit-hooks.d" ] ; then
        make_etc_link "dhcp/dhclient-exit-hooks.d/reset_dns" "dhcp/dhclient-exit-hooks.d/reset_dns"
      fi

      # Building Web GUI
      if [ "$OpenEPC_offline" = "true" ] ; then
        openepc_log "Offline mode.Skip web GUI dependencies installation..."
      else
        try_fail prereq_www
      fi
    
      openepc_log "Configuring Web Provisioning GUI for specific topology"
      cp -rf $OpenEPC_path_wharf/gui/www/* /var/www/html
      # Replace GUI configs and menu with setup-specific ones
      cd /var/www/html
      try_fail rm -rf lma-spgw lma-pgw pcef-spgw pcef-pgw mag-sgw mag-twag mag-epdg mag-angw bberf-sgw bberf-twag bberf-epdg enodeb2
      try_fail cp -rf lma lma-spgw
      try_fail cp -rf lma lma-pgw
      try_fail rm -rf lma
      try_fail cp -rf mag mag-sgw
      try_fail cp -rf mag mag-twag
      try_fail cp -rf mag mag-epdg
      try_fail cp -rf mag mag-angw
      try_fail rm -rf mag
      try_fail cp -rf pcef pcef-pgw
      try_fail cp -rf pcef pcef-spgw
      try_fail rm -rf pcef
      try_fail cp -rf bberf bberf-sgw
      try_fail cp -rf bberf bberf-twag
      try_fail cp -rf bberf bberf-epdg
      try_fail rm -rf bberf
      try_fail cp -rf enodeb enodeb2
      # $OpenEPC_path_etc/www holds preconfigured "config.inc" files. Those will be the ones actually used by the web gui.
      cp -rf "$OpenEPC_path_etc/www/"* /var/www/html/
      cp "$OpenEPC_path_etc/www/.htpasswd" /var/www/html/

      # Install pcscd for SIM card provisioning from GUI
      if [ "$OpenEPC_offline" = "true" ] ; then
        openepc_log "Offline mode.Skipping usim dependencies installation..."
      else
        try_skip prereq_usim
      fi

      # Download and install Kamailio (new OpenIMS)
      if [ "$OpenEPC_offline" = "true" ] ; then
        openepc_log "Offline mode.Skip Kamailio dependencies installation..."
      else
        cd "$OpenEPC_path_install"
        openepc_log "Installing Kamailio dependencies..."
        try_skip prereq_kamailio
      fi
         
      build_kamailio
      cd $OpenEPC_path_etc
      try_fail $OpenEPC_path_etc/cscf_expand_templates.sh

      # In order to set the MTU
      cd "$OpenEPC_path_etc"
      try_fail ./rc.local.allinone

      #Grant rights for managing the system via web interface
      if [ "$(grep -l www-data.*systemctl /etc/sudoers)" != "/etc/sudoers" ] ; then
        echo "" >> /etc/sudoers
        echo "www-data ALL=NOPASSWD: /bin/systemctl" >> /etc/sudoers;
        echo "www-data ALL=NOPASSWD: /sbin/start" >> /etc/sudoers;
        echo "www-data ALL=NOPASSWD: /sbin/stop" >> /etc/sudoers;
        echo "www-data ALL=NOPASSWD: /sbin/restart" >> /etc/sudoers;
      fi

      # Activate dummy0 interface
      try_fail modprobe dummy
      try_fail ifconfig dummy0 up

      # Add dummy to the module list loaded at boot 
      echo dummy >> /etc/modules-load.d/modules.conf 

      #Use the allinone config for SPGW instead of the normal one
      make_link $OpenEPC_path_etc/spgw_allinone.xml $OpenEPC_path_etc/spgw.xml

      services="spgw mme hss pcrf icscf pcscf scscf sms_router"
      service_enable_and_start_all $services
    ;;

  *)
      openepc_log_err "Configure system not implemented for node $OpenEPC_node !"

esac

screen -wipe

tput setaf 5 ; tput bold ;tput setaf 4 ; tput setab 7
echo -e "\n------------------------------------------------- OpenEPC Installation Script End -------------------------------------------------\n"
tput sgr 0
echo -e "\n\n"

if [ "$reboot_now" = "y" ] ; then
  openepc_log "Rebooting machine"
  #reboot
fi
