#!/bin/bash

function load_defaults {
    options="$SCRIPTS_PATH/default_options"
    bucket="$SCRIPTS_PATH/$RELATION_BUCKET"

    # If there are default options, load them 
    if [ -f $options ]; then
        source $options
    fi

    # If a relation bucket exists, load it
    if [ -f $bucket ];then
        source $bucket
    fi
}

function load_interface {
    intf_var=$1
    intf_ip=${!1}

    def_intf_var="${intf_var}_network_interface"
    def_intf=${!def_intf_var}
    def_intf_ip=${!def_intf}

    # Check if the interface name has been defined, else set it
    if [ -z $def_intf ]; then
        echo "$SERVICE: $def_intf_var not defined, will use default: $intf_var"
        declare $def_intf_var="$intf_var"
        def_intf=${!def_intf_var}
        def_intf_ip=${!def_intf}
    fi

    # Check if the interface IP has been defined, else set it
    if [ -z $def_intf_ip ]; then
        echo "$SERVICE: $def_intf_var IP not defined, will use default: $intf_ip"
        def_intf_ip=$intf_ip
    fi

    echo "$SERVICE: $intf_var IP before check: ${intf_ip} on ${def_intf}"

    declare $intf_var="$def_intf_ip"
    intf_ip=${!1}

    echo "$SERVICE: $intf_var IP after check: ${intf_ip} on ${def_intf}"

    if [ -z $intf_ip ]; then
        >&2 echo "$SERVICE: No IP on interface ${def_intf}!"
        exit 1
    fi
}

function save_to_relation_bucket {
    data_var=$1
    data=$2
    bucket="$SCRIPTS_PATH/$RELATION_BUCKET"

    # Save data to relation bucket
    echo "$data_var=\"$data\"\n" >> $bucket
}

function delete_from_relation_bucket {
    data_var=$1
    bucket="$SCRIPTS_PATH/$RELATION_BUCKET"

    # Delete data from relation bucket
    sed -i -e "/$data_var/d" $bucket
    echo "$SERVICE: Deleted ${data_var} from relation bucket"
}

function set_data_topology {
    data_var=$1
    data=$2

    # Overwrite the supplied variable in OpenEPC's data_topology_vars.sh
    if [ -f $DATA_TOP ]; then
        sed -i -e "s/\.*${data_var}=.*/${data_var}=\"${data}\" # NFV generated/" $DATA_TOP
        echo "$SERVICE: Set data topology ${data_var}=\"${data}\""
    else
        >&2 echo "$SERVICE: Could not find data topology file $DATA_TOP!"
	    exit 1
    fi
}

function set_data_installation {
    data_var=$1
    data=$2

    # Overwrite the supplied variable in OpenEPC's data_installation.sh
    if [ -f $DATA_INST ]; then
        sed -i -e "s/\.*${data_var}=.*/${data_var}=\"${data}\" # NFV generated/" $DATA_INST
        echo "$SERVICE: Set data installation ${data_var}=\"${data}\""
    else
        >&2 echo "$SERVICE: Could not find data installation file $DATA_INST!"
	    exit 1
    fi
}

function set_data_provisioning {
    data_var=$1
    data=$2

    # Overwrite the supplied variable in OpenEPC's data_provisioning_*.sh
    if [ -f $DATA_PROV ]; then
        sed -i -e "s/\.*${data_var}=.*/${data_var}=\"${data}\" # NFV generated/" $DATA_PROV
        echo "$SERVICE: Set data provisioning ${data_var}=\"${data}\""
    else
        >&2 echo "$SERVICE: Could not find data provisioning file $DATA_PROV!"
	    exit 1
    fi
}

function set_inetgw_dhcp {
    dhcp_default_route=$(ip route | grep default | awk '{print $3}')

    # Set inetgw IP to the default route currently set via DHCP
    set_data_topology "inetgw_mgmt_ipv4" $dhcp_default_route
}

function set_default_route_dhcp {
    dhcp_default_route=$(ip route | grep default | awk '{print $3}')

    # Set inetgw IP to the default route currently set via DHCP
    set_data_topology "inetgw_default_route_ipv4" $dhcp_default_route
}

function install_and_start {
    svc=$1
    params=$2
    install_system_script="$OPENEPC_PATH/install/$INSTALL_SYSTEM"

    # Run OpenEPC's install_system.sh script with the supplied parameters
    # This will also automatically start the related services
    if [ -f $install_system_script ]; then
        if [ -z "$EPC_CONFIGURE_LOG" ]; then
            EPC_CONFIGURE_LOG="/var/log/epc_configure.log"
        fi

        $install_system_script -s $svc $params >> $EPC_CONFIGURE_LOG 2>&1
    else
        >&2 echo "$SERVICE: Could not find install system script $install_system_script!"
	    exit 1
    fi
}

function add_route_broker {
    broker_ip=$(cat /etc/openbaton/ems/conf.ini | grep broker_ip | awk -F= '{print $2}')

    if [ -z $broker_ip ]; then
        >&2 echo "$SERVICE: Could not find broker IP in file /etc/openbaton/ems/conf.ini!"
	    exit 1
    fi
    
    if [ -f $DATA_TOP ]; then
        source $DATA_TOP
    else
        >&2 echo "$SERVICE: Could not find data topology file $DATA_TOP!"
	    exit 1
    fi

    # Add direct route to EMS broker to ensure connection
    ip route add $broker_ip via $inetgw_mgmt_ipv4
}

function install_packages {
    echo "$SERVICE : Installing packages"
    # Install packages and redirect stderr to our logfile

    # Check if we have set the option to allow downloading packages
    if [ ! $downloadPackages = "false" ];then
        echo "$SERVICE : Will install : $INSTALL_PACKAGES"
        apt-get update >> $LOGFILE 2>&1 && echo "$SERVICE : Finished update now installing packages" && apt-get install -y -q $INSTALL_PACKAGES >> $LOGFILE 2>&1
        echo "$SERVICE : Finished installing packages"
    fi
}