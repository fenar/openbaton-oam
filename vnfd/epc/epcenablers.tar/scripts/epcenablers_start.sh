#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

#install_and_start "epc-enablers"
install_and_start "epc-enablers" "--no-dns"

# Use HSS provisioning file if it exists
if [ -f "$HSS_PROVISION_DIR/$HSS_PROVISION_DB" ];then
	mysql -u root < $HSS_PROVISION_DIR/$HSS_PROVISION_DB
fi

# change the message packet size
ifconfig net_a mtu 1300 up

