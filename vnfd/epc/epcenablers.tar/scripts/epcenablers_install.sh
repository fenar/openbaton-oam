#!/bin/bash

function create_domain {
	# This part will probably be interesting if you want to use multiple network interfaces
	# Check if we have the dns network interface name saved in the configuration parameters
	if [ -z "$dns_network_interface" ];then
		echo "$SERVICE : dns_network_interface not defined, will use default : mgmt"
		dns_network_interface="mgmt"
	fi
	# Set the correct interface if we have changed the network name..
	com=pdns_ip\=\$$dns_network_interface
	eval $com
	com=pdns_floating_ip\=\$$dns_network_interface\_floatingIp
	eval $com
	if [ ! $useFloatingIpsForEntries = "false" ]; then
		if [ -z "$pdns_floating_ip" ]; then
			echo "$SERVICE : there is no floatingIP for the $dns_network_interface network for powerdns ! Will fallback using the normal interface ip"
			dns_ip=$pdns_ip
		else
			# Else we just overwrite the environment variable
			dns_ip=$pdns_floating_ip
		fi
	else
		dns_ip=$pdns_ip
	fi
	visisted=$(echo $realm | sed "s/mnc[0-9][0-9][0-9]/mnc002/")
}

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

load_interface "mgmt"
load_interface "net_a"

# Workaround to strip quotes from MCC and MNC that are required because Tacker would
# drop the leading zeroes otherwise
set_data_topology "mcc" "001"
set_data_topology "mnc_short" "01"
#set_data_topology "mcc" $(eval eval echo $mcc)
#set_data_topology "mnc_short" $(eval eval echo $mnc_short)

set_data_topology "hss_mgmt_ipv4" $mgmt
#set_data_topology "dns_mgmt_ipv4" "10.143.96.62"
set_data_topology "dns_mgmt_ipv4" $mgmt
set_data_topology "dns_net_a_ipv4" $net_a
set_data_topology "inetgw_mgmt_ipv4" $mgmt
#set_data_topology "inetgw_net_a_ipv4" $net_a
set_data_topology "inetgw_net_a_ipv4" "192.168.1.1"

#IMS configuration
set_data_topology "pcscf_net_a_ipv4" "192.168.1.45"
set_data_topology "pcscf_net_a_prefixv4" "$pcscf_net_a_ipv4/24"
set_data_topology "icscf_net_a_ipv4" "192.168.1.46"
set_data_topology "icscf_net_a_prefixv4" "$icscf_net_a_ipv4/24"
set_data_topology "scscf_net_a_ipv4" "192.168.1.47"
set_data_topology "scscf_net_a_prefixv4" "$scscf_net_a_ipv4/24"
set_data_topology "smsc_net_a_ipv4" "192.168.1.49"
set_data_topology "smsc_net_a_prefixv4" "$smsc_net_a_ipv4/24"

set_data_topology "www_mgmt_ipv4" $mgmt
set_data_topology "www_net_a_ipv4" $net_a

set_data_topology "pcrf_mgmt_ipv4" $mgmt
set_data_topology "pcrf_mgmt_diameter_port" "3869"

set_data_topology "pcscf_mgmt_ipv4" $mgmt
set_data_topology "pcscf_mgmt_diameter_port" "3870"
set_data_topology "pcscf_net_a_ipv4" $net_a
set_data_topology "pcscf_net_a_sip_port" "5060"

set_data_topology "icscf_mgmt_ipv4" $mgmt
set_data_topology "icscf_mgmt_diameter_port" "3871"
set_data_topology "icscf_net_a_ipv4" $net_a
set_data_topology "icscf_net_a_sip_port" "5061"

set_data_topology "scscf_mgmt_ipv4" $mgmt
set_data_topology "scscf_mgmt_diameter_port" "3872"
set_data_topology "scscf_net_a_ipv4" $net_a
set_data_topology "scscf_net_a_sip_port" "5062"

set_data_topology "smsc_mgmt_ipv4" $mgmt
set_data_topology "smsc_mgmt_diameter_port" "3873"
set_data_topology "smsc_net_a_ipv4" $net_a
set_data_topology "smsc_net_a_sip_port" "5063"

set_data_topology "http_proxy_mgmt_ipv4" $mgmt

set_default_route_dhcp

# Necessary so will not be prompted to enter a password for the mysql-root user
export DEBIAN_FRONTEND=noninteractive

echo "copying config.inc file"
cp "$SCRIPTS_PATH/config.inc" "$OPENEPC_PATH/etc/www/pdns/config.inc"

# Take care not to run the script twice
if [ -f "$SCRIPTS_PATH/powerdns-installed" ];then
	echo "$SERVICE: powerdns was installed already"
	# check if our service runs already, if not we can start it
	check=$(ps fax | grep pdns_server)
	if [ -z "$check" ];then
		service pdns start
		sleep 4s
		create_domain
	fi
	exit 0
fi

install_packages

# Allow connections to the database from the outside
sed -i -e "s/^\.*bind-address.*/bind-address = 0.0.0.0 \n /" $MYSQL_CONF

# Install PowerDNS
if [ ! $downloadPackages = "false" ];then
	echo "Package: pdns-*"  >> $PDNS_APT_PREF_FILE
	echo "Pin: origin repo.powerdns.com"  >> $PDNS_APT_PREF_FILE
	echo "Pin-Priority: 600"  >> $PDNS_APT_PREF_FILE

	echo $PDNS_XENIAL_REPO >> $PDNS_APT_FILE
	curl $PDNS_XENIAL_KEY | apt-key add - && apt-get update >> $LOGFILE 2>&1 && apt-get install pdns-server -y -q >> $LOGFILE 2>&1
fi

# Import the default table structure
if [ -f "$SCRIPTS_PATH/$TABLE_SKELETON" ];then
	echo "$SERVICE: Found mysql table skeleton, will import it"
	mysql -u root < $SCRIPTS_PATH/$TABLE_SKELETON
fi

# Clear up the default config files, check if dir exists and its empty
if [ -d "$POWERDNS_DIR" ];then
	echo "$SERVICE: Found powerdns config directory... Cleaning up"
	[ "$(ls -A $POWERDNS_DIR)" ] && rm $POWERDNS_DIR/* || echo "$SERVICE : directory was cleaned up already"
fi

# Copy sample config file into the powerdns config directory
if [ -f "$SCRIPTS_PATH/$POWERDNS_CONF" ];then
	echo "$SERVICE: Copying powerdns config files"
	cp $SCRIPTS_PATH/$POWERDNS_CONF $POWERDNS_DIR
fi

# Restart pdns to force reloading the config file
if [ ! $downloadPackages = "false" ];then
	sudo apt-get install -y -q $INSTALL_BACKEND_PACKAGES >> $LOGFILE 2>&1
else
	service pdns restart
fi

# Check if pdns is up and running, if the variable pdns_status is not empty , pdns is not running
pdns_status=$(service pdns status | grep not)
if [ ! -z "$pdns_status" ];then
	echo "$SERVICE: powerdns did not restart properly!"
	exit 1
fi

# Wait for PowerDNS
sleep 4s

# Now also check if we can reach our local power-dns, same as before, if the variables is not empty, we have a problem
pdns_status=$(dig @localhost | grep "timed out")
if [ ! -z "$pdns_status" ];then
	echo "$SERVICE: dig@localhost failed! Connection time out!"
	exit 1
fi

create_domain

touch $SCRIPTS_PATH/powerdns-installed
