--
-- Current Database: `powerdns`
--

USE `powerdns`;

LOCK TABLES `records` WRITE;
/*!40000 ALTER TABLE `records` DISABLE KEYS */;

-- EPC APNs - %base_realm
-- INSERT INTO `records` (domain_id, 	 name,				   type, 	prio, 		content,		 ttl, 		auth) VALUES
--  		      (10000,		 'net-d.spgw.node.VAR_REALM',      'A',         VAR_PRIO, 	'VAR_SPGW_NET_D',        3600,		1   )

UPDATE `records` SET content='VAR_SPGW_NET_D' WHERE name='net-d.spgw.node.VAR_REALM';

/*!40000 ALTER TABLE `records` ENABLE KEYS */;
UNLOCK TABLES;


-- ######################################
-- # 	Other entries related to spgw	#
-- ######################################

-- net_a - 1.168.192.in-addr.arpa
-- INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
--  (1001,'10.1.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',           3600,1)
 
-- net_b - 2.168.192.in-addr.arpa
-- INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
--  (1002,'10.2.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',         3600,1)

-- net_d - 4.168.192.in-addr.arpa
-- INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
--  (1004,'10.4.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',         3600,1)
  
-- mgmt - 254.168.192.in-addr.arpa'
-- INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
--  (1254,'10.254.168.192.in-addr.arpa',  'PTR','spgw.%base_realm',           3600,1)

-- EPC - %base_realm
-- INSERT INTO `records` (domain_id, name, type, content, ttl, auth) VALUES
--  (10000,'apn.%base_realm',           'A',    '%spgw_net_a_ipv4',        3600,1),
--  (10000,'%spgw_fqdn',                'A',    '%spgw_mgmt_ipv4',         3600,1)

-- EPC APNs - %base_realm
-- INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
--  (10000,'net-d.spgw.node.%base_realm',          'A',        10, '%spgw_net_d_ipv4',                                                          3600,1)
--  (10000,'%default_apn',                         'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
--  (10000,'%default_apn',                         'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),

--  (10000,'%internet_apn',                        'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
--  (10000,'%internet_apn',                        'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),

--  (10000,'%ims_apn',                             'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-gtp\"  \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
--  (10000,'%ims_apn',                             'NAPTR',    10, '100 999 \"s\" \"x-3gpp-pgw:x-s5-pmip\" \"\"    net-d-srv.spgw.node.%base_realm', 3600,1)

--  (10000,'net-d-srv.spgw.node.%base_realm',      'SRV',      10, '0 %spgw_net_d_gtpc_port net-d.spgw.node.%base_realm',                       3600,1),
--  (10000,'net-d.spgw.node.%base_realm',          'A',        10, '%spgw_net_d_ipv4',                                                          3600,1)

-- EPC TAC - %base_realm
-- INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
--  (10000,'tac-lb%enodeb_tac_lb.tac-hb%enodeb_tac_hb.tac.%base_realm',     'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s11\"     \"\"    net-d-srv.spgw.node.%base_realm', 3600,1),
--  (10000,'tac-lb%enodeb2_tac_lb.tac-hb%enodeb2_tac_hb.tac.%base_realm',   'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s11\"     \"\"    net-d-srv.spgw.node.%base_realm', 3600,1)


-- EPC RAC - %base_realm
-- INSERT INTO `records` (domain_id, name, type, prio, content, ttl, auth) VALUES
--  (10000,'rac%nodeb_rac.lac%nodeb_lac.rac.%base_realm',                   'NAPTR', 10,    '100 999 \"s\" \"x-3gpp-sgw:x-s4\"      \"\"    net-d-srv.spgw.node.%base_realm', 3600,1)

/*!40000 ALTER TABLE `records` ENABLE KEYS */;
-- UNLOCK TABLES;
