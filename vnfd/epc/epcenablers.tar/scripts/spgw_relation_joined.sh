#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

load_interface "spgw_mgmt"
load_interface "spgw_net_a"
load_interface "spgw_net_d"

save_to_relation_bucket "${spgw_hostname}_spgw_mgmt" $spgw_mgmt
save_to_relation_bucket "${spgw_hostname}_spgw_net_a" $spgw_net_a
save_to_relation_bucket "${spgw_hostname}_spgw_net_d" $spgw_net_d

set_data_topology "spgw_mgmt_ipv4" $spgw_mgmt
set_data_topology "spgw_net_a_ipv4" $spgw_net_a
set_data_topology "spgw_net_d_ipv4" $spgw_net_d
set_data_topology "spgw_pdn_ipv4_net" "$spgw_pdn_prefix_24.0\/24"

# Add spgw to PowerDNS for scaling demo
if [ -f "$SCRIPTS_PATH/powerdns-imported-template" ];then
	echo "$SERVICE: PowerDNS has already imported the epc template, this means we currently build up a relation to a spgw which is scaled out"
	echo "$SERVICE: Using template $SCRIPTS_PATH/$EPC_SPGW_TEMPLATE"
	echo "$SERVICE: Will create $EPC_SPGW_EXTENDED_TEMPLATE"
	# accordingly check to remove a existing prefilled template
	if [ -f "$EPC_SPGW_EXTENDED_TEMPLATE" ];then
		rm $EPC_SPGW_EXTENDED_TEMPLATE
	fi
	# fill out the template
	if [ -f "$SCRIPTS_PATH/$EPC_SPGW_TEMPLATE" ];then
		# first entry
		cat $SCRIPTS_PATH/$EPC_SPGW_TEMPLATE | sed "s/VAR_REALM/$realm/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
		# and the rest
		#cat $EPC_SPGW_EXTENDED_TEMPLATE | sed "s/VAR_PRIO/$prio/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
		cat $EPC_SPGW_EXTENDED_TEMPLATE | sed "s/VAR_SPGW_NET_D/$spgw_net_d/g" > $TMP_FILE && mv $TMP_FILE $EPC_SPGW_EXTENDED_TEMPLATE
	fi
fi
