#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

load_interface "mgmt"
load_interface "net_c"
load_interface "net_d"

set_data_topology "enodeb_mgmt_ipv4" $mgmt
# net_c is set via the spgw relation
set_data_topology "enodeb_net_c_ipv4" $net_c
set_data_topology "enodeb_net_d_ipv4" $net_d

set_inetgw_dhcp
