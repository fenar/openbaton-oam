#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

delete_from_relation_bucket "spgw_hostname"
save_to_relation_bucket "spgw_hostname" $spgw_hostname

spgw_pdn_prefix_24="192.168.3"
# moved this back to install script
#set_data_topology "enodeb_net_c_ipv4" "$spgw_pdn_prefix_24.1"
set_data_topology "spgw_pdn_ipv4_net" "$spgw_pdn_prefix_24.0\/24"
