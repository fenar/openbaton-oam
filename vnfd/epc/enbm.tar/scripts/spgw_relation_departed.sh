#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

# Detach users connected to this spgw
echo "Checking for $removing_hostname in $SCRIPTS_PATH"
if [ -f "$SCRIPTS_PATH/$removing_hostname" ];then

	while read imsi; do
		echo enodeb.detach $imsi | nc $mgmt 10000
		sleep 0.5s
	done < $SCRIPTS_PATH/$spgw_hostname
	# in the end delete the file
	rm $SCRIPTS_PATH/$spgw_hostname
fi
