#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

load_interface "mgmt"
load_interface "net_a"
load_interface "net_d"

set_data_topology "spgw_mgmt_ipv4" $mgmt
set_data_topology "spgw_net_a_ipv4" $net_a
set_data_topology "spgw_net_d_ipv4" $net_d

set_inetgw_dhcp

set_data_provisioning "data__pdn_ops__pdn_ipv4_range__1__start" $pdn_prefix_24.3
set_data_provisioning "data__pdn_ops__pdn_ipv4_range__1__end" $pdn_prefix_24.254
set_data_provisioning "data__pdn_ops__pdn_ipv4_range__1__mask" 255.255.255.0
set_data_provisioning "data__pdn_ops__pdn_ipv4_range__1__network" $pdn_prefix_24.0

# Avoid precursor setting on DNS
set_data_provisioning "data__pdn_ops__pdn_dns__1__addr" $pdn_dns

set_data_provisioning "data__pdn_ops__pdn_ipv4_allocation__1__ip" $pdn_prefix_24.100
set_data_provisioning "data__pdn_ops__pdn_ipv4_allocation__2__ip" $pdn_prefix_24.101
set_data_provisioning "data__pdn_ops__pdn_ipv4_allocation__3__ip" $pdn_prefix_24.102
set_data_provisioning "data__pdn_ops__pdn_ipv4_allocation__4__ip" $pdn_prefix_24.103
set_data_provisioning "data__pdn_ops__pdn_ipv4_allocation__5__ip" $pdn_prefix_24.104
