#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

load_interface "epcenablers_mgmt"
load_interface "epcenablers_net_a"

#set_data_topology "dns_mgmt_ipv4" "10.143.96.62"
set_data_topology "dns_mgmt_ipv4" $epcenablers_mgmt
set_data_topology "dns_net_a_ipv4" $epcenablers_net_a
#set_data_topology "inetgw_net_a_ipv4" $epcenablers_net_a
set_data_topology "inetgw_net_a_ipv4" "192.168.1.1"
# Workaround to strip quotes from MCC and MNC that are required because Tacker would
# drop the leading zeroes otherwise
set_data_topology "mcc" "001"
set_data_topology "mnc_short" "01"
#set_data_topology "mcc" $(eval eval echo $epcenablers_mcc)
#set_data_topology "mnc_short" $(eval eval echo $epcenablers_mnc_short)

set_data_topology "dns_mgmt_ipv4" $epcenablers_mgmt
set_data_topology "dns_net_a_ipv4" $epcenablers_net_a
set_data_topology "inetgw_net_a_ipv4" $epcenablers_net_a

set_data_topology "pcrf_mgmt_ipv4" $epcenablers_mgmt
set_data_topology "pcrf_mgmt_diameter_port" "3869"
