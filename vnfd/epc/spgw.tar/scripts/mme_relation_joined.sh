#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

load_interface "mme_mgmt"
load_interface "mme_net_d"

set_data_topology "mme_mgmt_ipv4" $mme_mgmt
set_data_topology "mme_net_d_ipv4" $mme_net_d
