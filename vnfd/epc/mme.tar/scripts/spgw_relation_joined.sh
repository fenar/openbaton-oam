#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

switch_num_file="$SCRIPTS_PATH/switch_num"

# Increase switch number for scaling demo
if [ ! -f "$switch_num_file" ];then
	echo "$SERVICE: First spgw connecting!"
	echo "1" > $switch_num_file
else
	sn=$(cat $switch_num_file)
	sn=$(($sn + 1))
	echo $sn > $switch_num_file
	echo "$SERVICE: spgw scaled out! We now have $sn spgws"
fi

save_to_relation_bucket "spgw_hostname" $spgw_hostname
