#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

switch_num_file="$SCRIPTS_PATH/switch_num"

# Decrease switch number for scaling demo
if [ ! -f "$switch_num_file" ];then
	echo "$SERVICE: No spgw connected yet!"
else
	sn=$(cat $switch_num_file )
	sn=$(($sn - 1))
	echo $sn > $switch_num_file
	echo "$SERVICE: spgw scaled in! We now have $sn spgws"
fi

delete_from_relation_bucket "spgw_hostname"
