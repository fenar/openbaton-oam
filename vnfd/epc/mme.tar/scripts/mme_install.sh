#!/bin/bash

if [ -f "$SCRIPTS_PATH/functions.sh" ]; then
	source $SCRIPTS_PATH/functions.sh
else
	>&2 echo "$SERVICE: Could not find functions file $SCRIPTS_PATH/functions.sh!"
	exit 1
fi

load_defaults

load_interface "mgmt"
load_interface "net_d"

set_data_topology "mme_mgmt_ipv4" $mgmt
set_data_topology "mme_net_d_ipv4" $net_d

set_inetgw_dhcp

#zabbix_conf="/etc/zabbix/zabbix_agentd.conf"
zabbix_path="/opt/zabbix"

# If Zabbix Agent is available, inject configuration for scaling demo
if [ -f $zabbix_path ]; then
	cp $SCRIPTS_PATH/$USER_PARAM $zabbix_path/

	echo "UnsafeUserParameters=1" >> $zabbix_path
	if [ -d $zabbix_path ]; then
		sed -i -e "s/\VAR_MME_MGMT/$mgmt/g" $zabbix_path/$USER_PARAM
	fi

	# Restart Zabbix Agent
	service zabbix-agent restart 2>&1
fi
